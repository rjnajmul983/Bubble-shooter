extends Node

const SFX_POOL_SIZE := 16

var _sfx_players: Array[AudioStreamPlayer] = []
var _sfx_cursor := 0
var _sfx_cache: Dictionary = {}

var _bgm_a: AudioStreamPlayer
var _bgm_b: AudioStreamPlayer
var _active_bgm: AudioStreamPlayer
var _current_bgm_name := ""
var _bgm_tween: Tween

var _music_bus_idx := -1
var _sfx_bus_idx := -1
var _lowpass_effect: AudioEffectLowPassFilter


func _ready() -> void:
	_setup_audio_buses()
	_setup_players()
	_preload_sfx()
	apply_settings()


func _setup_audio_buses() -> void:
	if AudioServer.get_bus_index("Music") == -1:
		var idx := AudioServer.bus_count
		AudioServer.add_bus(idx)
		AudioServer.set_bus_name(idx, "Music")
		AudioServer.set_bus_send(idx, "Master")
	if AudioServer.get_bus_index("SFX") == -1:
		var idx := AudioServer.bus_count
		AudioServer.add_bus(idx)
		AudioServer.set_bus_name(idx, "SFX")
		AudioServer.set_bus_send(idx, "Master")

	_music_bus_idx = AudioServer.get_bus_index("Music")
	_sfx_bus_idx = AudioServer.get_bus_index("SFX")

	_lowpass_effect = AudioEffectLowPassFilter.new()
	_lowpass_effect.cutoff_hz = 20000.0
	AudioServer.add_bus_effect(_music_bus_idx, _lowpass_effect)


func _setup_players() -> void:
	for i in range(SFX_POOL_SIZE):
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_sfx_players.append(p)

	_bgm_a = AudioStreamPlayer.new()
	_bgm_a.bus = "Music"
	add_child(_bgm_a)

	_bgm_b = AudioStreamPlayer.new()
	_bgm_b.bus = "Music"
	add_child(_bgm_b)

	_active_bgm = _bgm_a


func _preload_sfx() -> void:
	var names := [
		"sfx_shoot", "sfx_bounce", "sfx_drop", "sfx_ice_crack",
		"sfx_lock_break", "sfx_stone_clink", "sfx_bomb", "sfx_lightning",
		"sfx_rainbow", "sfx_swap", "sfx_boss_hit", "sfx_ceiling_drop",
		"sfx_win", "sfx_lose", "sfx_ui_tap", "sfx_ui_back",
		"sfx_pop_1", "sfx_pop_2", "sfx_pop_3", "sfx_pop_4",
		"sfx_pop_5", "sfx_pop_6", "sfx_pop_7", "sfx_pop_8",
	]
	for n in names:
		var path := "res://assets/audio/%s.wav" % n
		if ResourceLoader.exists(path):
			_sfx_cache[n] = load(path)


func apply_settings() -> void:
	var master_v: float = clampf(float(SaveManager.get_setting("master_vol", 0.9)), 0.0, 1.0)
	var music_v: float = clampf(float(SaveManager.get_setting("music_vol", 0.65)), 0.0, 1.0)
	var sfx_v: float = clampf(float(SaveManager.get_setting("sfx_vol", 0.95)), 0.0, 1.0)
	var music_muted: bool = bool(SaveManager.get_setting("music_muted", false))
	var sfx_muted: bool = bool(SaveManager.get_setting("sfx_muted", false))

	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(0.0001, master_v)))
	AudioServer.set_bus_volume_db(_music_bus_idx, linear_to_db(maxf(0.0001, music_v)))
	AudioServer.set_bus_volume_db(_sfx_bus_idx, linear_to_db(maxf(0.0001, sfx_v)))
	AudioServer.set_bus_mute(_music_bus_idx, music_muted or music_v <= 0.001)
	AudioServer.set_bus_mute(_sfx_bus_idx, sfx_muted or sfx_v <= 0.001)


func play_sfx(sfx_name: String, pitch_scale := 1.0, volume_db := 0.0) -> void:
	if not _sfx_cache.has(sfx_name):
		return
	var p: AudioStreamPlayer = _sfx_players[_sfx_cursor]
	_sfx_cursor = (_sfx_cursor + 1) % SFX_POOL_SIZE
	p.stream = _sfx_cache[sfx_name]
	p.pitch_scale = pitch_scale
	p.volume_db = volume_db
	p.play()


func play_pop_combo(combo_step: int) -> void:
	var idx := clampi(combo_step, 1, 8)
	var extra_pitch := 1.0 + maxf(0.0, float(combo_step - 8) * 0.04)
	play_sfx("sfx_pop_%d" % idx, minf(1.35, extra_pitch), -1.0)


func play_bgm(track_filename: String, fade_sec := 0.8) -> void:
	if track_filename == _current_bgm_name and _active_bgm.playing:
		return
	var path := "res://assets/audio/%s" % track_filename
	if not ResourceLoader.exists(path):
		return
	var stream: AudioStream = load(path)
	if stream == null:
		return
	if stream is AudioStreamOggVorbis:
		stream.loop = true

	_current_bgm_name = track_filename
	var incoming: AudioStreamPlayer = _bgm_b if _active_bgm == _bgm_a else _bgm_a
	var outgoing: AudioStreamPlayer = _active_bgm
	_active_bgm = incoming

	incoming.stream = stream
	incoming.volume_db = -40.0
	incoming.pitch_scale = 1.0
	incoming.play()

	if _bgm_tween and _bgm_tween.is_valid():
		_bgm_tween.kill()
	_bgm_tween = create_tween().set_parallel(true)
	_bgm_tween.tween_property(incoming, "volume_db", -2.0, fade_sec)
	if outgoing.playing:
		_bgm_tween.tween_property(outgoing, "volume_db", -40.0, fade_sec)
		_bgm_tween.chain().tween_callback(outgoing.stop)


func set_paused_muffle(paused: bool) -> void:
	if _lowpass_effect == null:
		return
	var tw := create_tween()
	tw.tween_property(_lowpass_effect, "cutoff_hz", 900.0 if paused else 20000.0, 0.25)


func set_tension_mode(high_tension: bool) -> void:
	if _active_bgm == null or not _active_bgm.playing:
		return
	var tw := create_tween()
	tw.tween_property(_active_bgm, "pitch_scale", 1.045 if high_tension else 1.0, 0.45)
