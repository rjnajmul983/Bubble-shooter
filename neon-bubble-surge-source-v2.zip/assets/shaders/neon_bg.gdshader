shader_type canvas_item;

uniform vec4 color_top : source_color = vec4(0.03, 0.04, 0.12, 1.0);
uniform vec4 color_bot : source_color = vec4(0.08, 0.14, 0.28, 1.0);
uniform vec4 accent_color : source_color = vec4(0.0, 0.96, 1.0, 1.0);

void fragment() {
	vec2 uv = UV;
	float t = TIME * 0.28;
	vec3 base = mix(color_top.rgb, color_bot.rgb, smoothstep(0.0, 1.0, uv.y));

	// Smooth drifting neon aurora ribbon (zero texture lookups, 120fps friendly)
	float wave1 = sin(uv.x * 3.8 + t) * 0.12 + cos(uv.y * 2.5 - t * 0.7) * 0.10;
	float glow1 = exp(-pow((uv.y - 0.32 + wave1) * 4.2, 2.0)) * 0.20;

	float wave2 = cos(uv.x * 2.6 - t * 0.85) * 0.14;
	float glow2 = exp(-pow((uv.y - 0.74 + wave2) * 3.6, 2.0)) * 0.14;

	// Subtle radial vignette for high bubble readability
	float vig = smoothstep(1.15, 0.25, length(uv - vec2(0.5)));
	vec3 col = base * (0.72 + 0.28 * vig) + accent_color.rgb * (glow1 + glow2);
	COLOR = vec4(col, 1.0);
}
