extends Node


func _enabled() -> bool:
	return bool(SaveManager.get_setting("haptics", true))


func tap() -> void:
	if _enabled():
		Input.vibrate_handheld(12)


func pop() -> void:
	if _enabled():
		Input.vibrate_handheld(18)


func combo() -> void:
	if _enabled():
		Input.vibrate_handheld(34)


func heavy() -> void:
	if _enabled():
		Input.vibrate_handheld(62)
