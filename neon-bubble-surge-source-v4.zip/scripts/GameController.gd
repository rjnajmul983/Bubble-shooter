extends Node2D

const PLAYFIELD_LEFT := 56.0
const PLAYFIELD_RIGHT := 1024.0
const PLAYFIELD_TOP := 230.0
const DANGER_LINE_Y := 1420.0
const SHOOTER_POS := Vector2(540.0, 1575.0)
const NEXT_BUBBLE_OFFSET := Vector2(-150.0, 12.0)
const BUBBLE_RADIUS := 44.0
const SHOT_SPEED := 1950.0
const SLINGSHOT_GRAB_RADIUS := 145.0
const SLINGSHOT_MAX_PULL := 85.0
const SLINGSHOT_MIN_PULL := 18.0
const CANCEL_ZONE_Y := 1700.0
const NEXT_BUBBLE_HIT_RADIUS := 88.0

var hex := HexGrid.new()
var grid: Dictionary = {}  # Vector2i -> {"color": int, "type": String, "node": BubbleNode}

var level_id: int = 1
var level_cfg: Dictionary = {}
var world_cfg: Dictionary = {}

var shots_left: int = 20
var shots_taken_since_drop: int = 0
var ceiling_interval: int = 0
var timer_remaining: float = 0.0
var is_timed: bool = false
var is_boss: bool = false
var boss_hp: int = 0
var boss_max_hp: int = 0
var boss_cell: Vector2i = Vector2i(0, 5)
var num_colors: int = 5

var score: int = 0
var combo_streak: int = 0
var star_thresholds: Array = [3000, 6000, 9000]

var cur_color: int = 0
var next_color: int = 1
var active_powerup: String = ""  # "", "bomb", "lightning", "aim"

var is_shooting: bool = false
var is_aiming: bool = false
var aim_mode: String = ""  # "slingshot" or "direct"
var active_touch_id: int = -1
var aim_cancelled: bool = false  # aim was cancelled by 2nd finger; first finger still down
var touch_start_pos: Vector2 = Vector2.ZERO
var touch_max_drag: float = 0.0
var is_game_over: bool = false
var is_paused: bool = false
var aim_dir: Vector2 = Vector2.UP
var aim_valid: bool = false

var flying_node: BubbleNode = null
var flying_vel: Vector2 = Vector2.ZERO
var flying_bounces: int = 0

var shake_strength: float = 0.0

# Scene layers
var bg_rect: ColorRect
var play_layer: Node2D
var bubble_layer: Node2D
var fx_layer: Node2D
var aim_renderer: AimRenderer
var cannon_root: Node2D
var cur_preview: BubbleNode
var next_preview: BubbleNode
var ceiling_bar: ColorRect
var danger_line: Line2D

# HUD widgets
var ui_layer: CanvasLayer
var lbl_level: Label
var lbl_score: Label
var lbl_shots: Label
var lbl_timer: Label
var lbl_ceiling: Label
var boss_bar_bg: PanelContainer
var boss_bar: ProgressBar
var boss_lbl: Label
var star_bar: ProgressBar
var btn_pu: Dictionary = {}
var popup_root: Control
var cancel_hint_panel: PanelContainer


func _ready() -> void:
	level_id = LevelData.selected_level_id
	level_cfg = LevelData.get_level(level_id)
	world_cfg = LevelData.get_world_for_level(level_id)

	hex.radius = BUBBLE_RADIUS
	hex.origin = Vector2(PLAYFIELD_LEFT, PLAYFIELD_TOP)
	hex.ceiling_offset_rows = 0

	_build_scene_hierarchy()
	_build_hud()
	_load_level_state()
	AudioManager.play_bgm(world_cfg.get("bgm", "bgm_world_cyber.ogg"))


func _build_scene_hierarchy() -> void:
	# Animated neon background shader covering full tall Android 16 displays
	bg_rect = ColorRect.new()
	var vp_sz := get_viewport_rect().size
	bg_rect.position = Vector2(-200, -200)
	bg_rect.size = Vector2(maxf(1480.0, vp_sz.x + 400.0), maxf(2800.0, vp_sz.y + 400.0))
	bg_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var mat := ShaderMaterial.new()
	mat.shader = load("res://assets/shaders/neon_bg.gdshader")
	var pal: Array = world_cfg.get("palette", ["#080B1E", "#132248", "#00F5FF"])
	mat.set_shader_parameter("color_top", Color(pal[0]))
	mat.set_shader_parameter("color_bot", Color(pal[1]))
	mat.set_shader_parameter("accent_color", Color(pal[2]))
	bg_rect.material = mat
	add_child(bg_rect)

	play_layer = Node2D.new()
	add_child(play_layer)

	# Side neon bumper walls
	var wall_col := Color(pal[2])
	wall_col.a = 0.55
	for wx in [PLAYFIELD_LEFT - 8.0, PLAYFIELD_RIGHT + 2.0]:
		var wall := ColorRect.new()
		wall.position = Vector2(wx, PLAYFIELD_TOP - 20.0)
		wall.size = Vector2(6.0, DANGER_LINE_Y - PLAYFIELD_TOP + 120.0)
		wall.color = wall_col
		wall.mouse_filter = Control.MOUSE_FILTER_IGNORE
		play_layer.add_child(wall)

	# Ceiling bar
	ceiling_bar = ColorRect.new()
	ceiling_bar.position = Vector2(PLAYFIELD_LEFT - 6.0, PLAYFIELD_TOP - 14.0)
	ceiling_bar.size = Vector2(PLAYFIELD_RIGHT - PLAYFIELD_LEFT + 12.0, 14.0)
	ceiling_bar.color = Color(pal[2])
	ceiling_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	play_layer.add_child(ceiling_bar)

	# Danger line
	danger_line = Line2D.new()
	danger_line.add_point(Vector2(PLAYFIELD_LEFT, DANGER_LINE_Y))
	danger_line.add_point(Vector2(PLAYFIELD_RIGHT, DANGER_LINE_Y))
	danger_line.width = 4.0
	danger_line.default_color = Color("#FF2A6D", 0.55)
	play_layer.add_child(danger_line)

	aim_renderer = AimRenderer.new()
	aim_renderer.z_index = 25
	play_layer.add_child(aim_renderer)

	bubble_layer = Node2D.new()
	play_layer.add_child(bubble_layer)

	fx_layer = Node2D.new()
	fx_layer.z_index = 40
	play_layer.add_child(fx_layer)

	# Shooter cannon assembly
	cannon_root = Node2D.new()
	cannon_root.position = SHOOTER_POS
	cannon_root.z_index = 30
	play_layer.add_child(cannon_root)

	# Glowing outer shooter ring
	var outer_ring := Line2D.new()
	outer_ring.width = 5.0
	outer_ring.default_color = Color(pal[2], 0.72)
	for i in range(41):
		var ang := (float(i) / 40.0) * TAU
		outer_ring.add_point(Vector2(cos(ang), sin(ang)) * 74.0)
	cannon_root.add_child(outer_ring)

	var ring := Polygon2D.new()
	var pts := PackedVector2Array()
	for i in range(36):
		var ang := (float(i) / 36.0) * TAU
		pts.append(Vector2(cos(ang), sin(ang)) * 70.0)
	ring.polygon = pts
	ring.color = Color(0.08, 0.12, 0.25, 0.85)
	cannon_root.add_child(ring)

	# Subtle glowing ring around next bubble (tap directly on bubble to swap!)
	var next_ring := Line2D.new()
	next_ring.width = 3.5
	next_ring.default_color = Color(pal[2], 0.55)
	for i in range(33):
		var ang := (float(i) / 32.0) * TAU
		next_ring.add_point(NEXT_BUBBLE_OFFSET + Vector2(cos(ang), sin(ang)) * 46.0)
	cannon_root.add_child(next_ring)

	cur_preview = BubbleNode.new()
	cannon_root.add_child(cur_preview)

	next_preview = BubbleNode.new()
	next_preview.position = NEXT_BUBBLE_OFFSET
	next_preview.scale = Vector2(0.76, 0.76)
	cannon_root.add_child(next_preview)


func _build_hud() -> void:
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)

	# Top HUD bar
	var top_panel := PanelContainer.new()
	top_panel.position = Vector2(24, 34)
	top_panel.size = Vector2(1032, 160)
	var top_sb := StyleBoxFlat.new()
	top_sb.bg_color = Color(0.04, 0.06, 0.14, 0.82)
	top_sb.corner_radius_top_left = 24
	top_sb.corner_radius_top_right = 24
	top_sb.corner_radius_bottom_left = 24
	top_sb.corner_radius_bottom_right = 24
	top_sb.border_width_bottom = 2
	top_sb.border_color = Color(world_cfg.get("palette", ["#080B1E", "#132248", "#00F5FF"])[2])
	top_panel.add_theme_stylebox_override("panel", top_sb)
	ui_layer.add_child(top_panel)

	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 16)
	top_panel.add_child(hbox)

	var left_v := VBoxContainer.new()
	left_v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hbox.add_child(left_v)

	lbl_level = Label.new()
	lbl_level.add_theme_font_size_override("font_size", 32)
	lbl_level.add_theme_color_override("font_color", Color("#FFFFFF"))
	left_v.add_child(lbl_level)

	lbl_score = Label.new()
	lbl_score.add_theme_font_size_override("font_size", 28)
	lbl_score.add_theme_color_override("font_color", Color("#00F5FF"))
	left_v.add_child(lbl_score)

	star_bar = ProgressBar.new()
	star_bar.custom_minimum_size = Vector2(360, 18)
	star_bar.show_percentage = false
	left_v.add_child(star_bar)

	var mid_v := VBoxContainer.new()
	mid_v.alignment = BoxContainer.ALIGNMENT_CENTER
	hbox.add_child(mid_v)

	lbl_shots = Label.new()
	lbl_shots.add_theme_font_size_override("font_size", 42)
	lbl_shots.add_theme_color_override("font_color", Color("#FFD700"))
	lbl_shots.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mid_v.add_child(lbl_shots)

	lbl_timer = Label.new()
	lbl_timer.add_theme_font_size_override("font_size", 24)
	lbl_timer.add_theme_color_override("font_color", Color("#FF5C8A"))
	lbl_timer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mid_v.add_child(lbl_timer)

	lbl_ceiling = Label.new()
	lbl_ceiling.add_theme_font_size_override("font_size", 22)
	lbl_ceiling.add_theme_color_override("font_color", Color("#A855F7"))
	lbl_ceiling.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mid_v.add_child(lbl_ceiling)

	var btn_pause := _make_styled_button("II", Vector2(96, 96), Color("#1E293B"), 34)
	btn_pause.pressed.connect(_on_pause_pressed)
	hbox.add_child(btn_pause)

	# Boss HP bar (hidden unless boss level)
	boss_bar_bg = PanelContainer.new()
	boss_bar_bg.position = Vector2(210, 196)
	boss_bar_bg.size = Vector2(660, 42)
	boss_bar_bg.visible = false
	ui_layer.add_child(boss_bar_bg)

	var bv := VBoxContainer.new()
	boss_bar_bg.add_child(bv)
	boss_lbl = Label.new()
	boss_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	boss_lbl.add_theme_font_size_override("font_size", 22)
	boss_lbl.add_theme_color_override("font_color", Color("#FF2A85"))
	bv.add_child(boss_lbl)
	boss_bar = ProgressBar.new()
	boss_bar.custom_minimum_size = Vector2(640, 14)
	boss_bar.show_percentage = false
	bv.add_child(boss_bar)

	# Cancel feedback banner (appears when dragging down to bottom cancel zone)
	cancel_hint_panel = PanelContainer.new()
	cancel_hint_panel.position = Vector2(290, 1668)
	cancel_hint_panel.size = Vector2(500, 62)
	cancel_hint_panel.visible = false
	cancel_hint_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var csb := StyleBoxFlat.new()
	csb.bg_color = Color(0.55, 0.06, 0.18, 0.92)
	csb.corner_radius_top_left = 20
	csb.corner_radius_top_right = 20
	csb.corner_radius_bottom_left = 20
	csb.corner_radius_bottom_right = 20
	csb.border_width_left = 2
	csb.border_width_top = 2
	csb.border_width_right = 2
	csb.border_width_bottom = 2
	csb.border_color = Color("#FF4D6D")
	cancel_hint_panel.add_theme_stylebox_override("panel", csb)
	ui_layer.add_child(cancel_hint_panel)

	var clbl := Label.new()
	clbl.text = "RELEASE TO CANCEL SHOT"
	clbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	clbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	clbl.add_theme_font_size_override("font_size", 26)
	clbl.add_theme_color_override("font_color", Color.WHITE)
	cancel_hint_panel.add_child(clbl)

	# Bottom Power-Up dock
	var pu_hbox := HBoxContainer.new()
	pu_hbox.position = Vector2(44, 1760)
	pu_hbox.size = Vector2(992, 130)
	pu_hbox.add_theme_constant_override("separation", 18)
	pu_hbox.alignment = BoxContainer.ALIGNMENT_CENTER
	ui_layer.add_child(pu_hbox)

	var pu_defs := [
		["bomb", "BOMB", Color("#DC2626")],
		["lightning", "ZAP ROW", Color("#0284C7")],
		["swap", "RAINBOW", Color("#9333EA")],
		["aim", "LASER", Color("#059669")],
	]
	for pd in pu_defs:
		var b := _make_styled_button(pd[1], Vector2(228, 114), pd[2], 24)
		var kind: String = pd[0]
		b.pressed.connect(func(): _on_powerup_pressed(kind))
		pu_hbox.add_child(b)
		btn_pu[kind] = b

	popup_root = Control.new()
	popup_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	popup_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_layer.add_child(popup_root)


func _make_styled_button(txt: String, min_sz: Vector2, col: Color, font_sz: int = 28) -> Button:
	var b := Button.new()
	b.text = txt
	b.custom_minimum_size = min_sz
	b.add_theme_font_size_override("font_size", font_sz)
	b.add_theme_color_override("font_color", Color.WHITE)
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	sb.corner_radius_top_left = 18
	sb.corner_radius_top_right = 18
	sb.corner_radius_bottom_left = 18
	sb.corner_radius_bottom_right = 18
	sb.border_width_left = 2
	sb.border_width_top = 2
	sb.border_width_right = 2
	sb.border_width_bottom = 4
	sb.border_color = col.lightened(0.45)
	b.add_theme_stylebox_override("normal", sb)
	var sb_h := sb.duplicate()
	sb_h.bg_color = col.lightened(0.15)
	b.add_theme_stylebox_override("hover", sb_h)
	b.add_theme_stylebox_override("pressed", sb_h)
	return b


func _load_level_state() -> void:
	for c in bubble_layer.get_children():
		c.queue_free()
	grid.clear()

	shots_left = int(level_cfg.get("shots", 22))
	shots_taken_since_drop = 0
	ceiling_interval = int(level_cfg.get("ceiling_interval", 0))
	timer_remaining = float(level_cfg.get("timer_sec", 0))
	is_timed = timer_remaining > 0.0
	is_boss = bool(level_cfg.get("is_boss", false))
	boss_hp = int(level_cfg.get("boss_hp", 0))
	boss_max_hp = boss_hp
	num_colors = int(level_cfg.get("colors", 5))
	star_thresholds = level_cfg.get("star_thresholds", [3000, 6000, 9000])
	score = 0
	combo_streak = 0
	active_powerup = ""
	is_game_over = false
	is_paused = false
	_reset_touch_state()
	hex.ceiling_offset_rows = 0
	ceiling_bar.position.y = PLAYFIELD_TOP - 14.0

	var raw_grid: Array = level_cfg.get("grid", [])
	for item in raw_grid:
		var cell := Vector2i(int(item["r"]), int(item["c"]))
		var col := int(item["color"])
		var btype := String(item["type"])
		var node := BubbleNode.new()
		node.setup(col, btype, BUBBLE_RADIUS * 2.0)
		node.position = hex.cell_to_world(cell.x, cell.y)
		node.grid_cell = cell
		bubble_layer.add_child(node)
		grid[cell] = {"color": col, "type": btype, "node": node}
		if btype == "B":
			boss_cell = cell

	boss_bar_bg.visible = is_boss
	cur_color = _pick_smart_color()
	next_color = _pick_smart_color()
	_refresh_shooter_previews()
	_update_hud()
	AudioManager.set_tension_mode(is_boss)


func _pick_smart_color() -> int:
	var present := {}
	for b in grid.values():
		if b["type"] in ["n", "i", "l"] and int(b["color"]) >= 0:
			present[int(b["color"])] = true
	if present.is_empty():
		return randi() % max(1, num_colors)
	var keys := present.keys()
	return int(keys[randi() % keys.size()])


func _refresh_shooter_previews() -> void:
	if active_powerup == "bomb":
		cur_preview.setup(-1, "b", BUBBLE_RADIUS * 2.05)
	elif active_powerup == "swap":
		cur_preview.setup(-1, "r", BUBBLE_RADIUS * 2.05)
	else:
		cur_preview.setup(cur_color, "n", BUBBLE_RADIUS * 2.0)
	next_preview.setup(next_color, "n", BUBBLE_RADIUS * 2.0)


func _update_hud() -> void:
	var wname: String = world_cfg.get("name", "World")
	lbl_level.text = "LV %d • %s%s" % [level_id, wname, " [BOSS]" if is_boss else ""]
	lbl_score.text = "SCORE: %d" % score
	lbl_shots.text = "%d SHOTS" % shots_left
	lbl_shots.add_theme_color_override("font_color", Color("#FF3B30") if shots_left <= 5 else Color("#FFD700"))

	star_bar.max_value = float(star_thresholds[2])
	star_bar.value = minf(float(score), float(star_thresholds[2]))

	lbl_timer.visible = is_timed
	if is_timed:
		lbl_timer.text = "TIME: %ds" % int(ceil(timer_remaining))

	lbl_ceiling.visible = ceiling_interval > 0
	if ceiling_interval > 0:
		var rem := ceiling_interval - shots_taken_since_drop
		lbl_ceiling.text = "DROP IN: %d" % rem

	if is_boss:
		boss_bar.max_value = maxf(1.0, float(boss_max_hp))
		boss_bar.value = float(boss_hp)
		boss_lbl.text = "BOSS CORE HP: %d / %d" % [boss_hp, boss_max_hp]

	var names := {"bomb": "BOMB", "lightning": "ZAP ROW", "swap": "RAINBOW", "aim": "LASER"}
	for k in btn_pu.keys():
		var cnt := SaveManager.get_powerup_count(k)
		var active_mark := " [ON]" if active_powerup == k else ""
		btn_pu[k].text = "%s\n(%d)%s" % [names[k], cnt, active_mark]

	AudioManager.set_tension_mode(is_boss or shots_left <= 5 or (is_timed and timer_remaining <= 15.0))


func _process(delta: float) -> void:
	if is_paused or is_game_over:
		return

	if shake_strength > 0.1:
		shake_strength = lerpf(shake_strength, 0.0, delta * 14.0)
		play_layer.position = Vector2(randf_range(-shake_strength, shake_strength), randf_range(-shake_strength, shake_strength))
	else:
		play_layer.position = Vector2.ZERO

	if is_timed:
		timer_remaining -= delta
		if timer_remaining <= 0.0:
			timer_remaining = 0.0
			_update_hud()
			_trigger_lose("TIME EXPIRED!")
			return
		lbl_timer.text = "TIME: %ds" % int(ceil(timer_remaining))

	if is_shooting and flying_node != null:
		_step_projectile(delta)


func _is_point_on_hud(pos: Vector2) -> bool:
	return pos.y < 205.0 or pos.y > 1745.0


func _is_on_next_bubble(pos: Vector2) -> bool:
	return pos.distance_to(SHOOTER_POS + NEXT_BUBBLE_OFFSET) <= NEXT_BUBBLE_HIT_RADIUS


func _cancel_aim() -> void:
	# Drops the running target without firing. The bubble stays loaded and can be swapped.
	is_aiming = false
	aim_valid = false
	aim_mode = ""
	touch_max_drag = 0.0
	if cancel_hint_panel != null:
		cancel_hint_panel.visible = false
	if cur_preview != null:
		cur_preview.position = Vector2.ZERO
	if aim_renderer != null:
		aim_renderer.clear_aim()


func _reset_touch_state() -> void:
	_cancel_aim()
	active_touch_id = -1
	aim_cancelled = false


func _notification(what: int) -> void:
	# App goes to background / loses focus mid-aim: never leave a stuck target behind.
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		_reset_touch_state()


func _input(event: InputEvent) -> void:
	# Only real touch events are used. On Android Godot ALSO sends an emulated mouse event for
	# every touch; reading both made one tap count twice (swap, then swap back = "no change").
	# On desktop, emulate_touch_from_mouse already converts mouse clicks into touch events.
	var touch := event as InputEventScreenTouch
	var drag := event as InputEventScreenDrag
	if touch == null and drag == null:
		return

	var idx: int = touch.index if touch != null else drag.index

	if is_paused or is_game_over or is_shooting:
		if touch != null and not touch.pressed and idx == active_touch_id:
			active_touch_id = -1
			aim_cancelled = false
		return

	var raw_pos: Vector2 = touch.position if touch != null else drag.position
	var pos: Vector2 = get_canvas_transform().affine_inverse() * raw_pos

	# ---------------- finger moved ----------------
	if drag != null:
		if idx != active_touch_id or not is_aiming:
			return
		touch_max_drag = maxf(touch_max_drag, pos.distance_to(touch_start_pos))
		_update_aim_from_pointer(pos)
		return

	# ---------------- finger lifted ----------------
	if not touch.pressed:
		if idx != active_touch_id:
			return
		active_touch_id = -1
		aim_cancelled = false
		if not is_aiming:
			return
		if touch.canceled:
			# Android took the touch away (system gesture etc.) -> never fire
			_cancel_aim()
			return
		_release_aim(pos)
		return

	# ---------------- finger put down ----------------
	if active_touch_id != -1:
		# A SECOND finger while the first one is still down:
		#   - cancels the running target (nothing is fired)
		#   - if it lands on the next bubble it also swaps the bubbles
		if is_aiming:
			_cancel_aim()
			aim_cancelled = true
			HapticsManager.tap()
			_spawn_floating_text(SHOOTER_POS + Vector2(0, -130), "CANCELLED", Color("#FF5C8A"))
		if _is_on_next_bubble(pos):
			_on_quick_swap()
		return

	if _is_point_on_hud(pos):
		return

	# Touching ONLY the bubble swaps immediately (no SWAP button needed)
	if _is_on_next_bubble(pos):
		_on_quick_swap()
		return

	active_touch_id = idx
	aim_cancelled = false
	touch_start_pos = pos
	touch_max_drag = 0.0
	is_aiming = true

	# Touching on/near the shooter bubble activates Slingshot Pull-Back aiming
	if pos.distance_to(SHOOTER_POS) <= SLINGSHOT_GRAB_RADIUS or pos.y >= SHOOTER_POS.y - 60.0:
		aim_mode = "slingshot"
		HapticsManager.tap()
	else:
		aim_mode = "direct"
	_update_aim_from_pointer(pos)


func _release_aim(pos: Vector2) -> void:
	var was_tap_on_shooter := (
		touch_start_pos.distance_to(SHOOTER_POS) <= 92.0
		and touch_max_drag < SLINGSHOT_MIN_PULL
		and pos.y < CANCEL_ZONE_Y
	)
	var should_fire := aim_valid
	_cancel_aim()

	if was_tap_on_shooter:
		# Quick tap on the shooter bubble itself also swaps the bubble
		_on_quick_swap()
	elif should_fire:
		_fire_bubble()


func _update_aim_from_pointer(pos: Vector2) -> void:
	# Dragging finger all the way down to the bottom cancel zone cancels the active shot!
	if pos.y >= CANCEL_ZONE_Y:
		aim_valid = false
		cur_preview.position = Vector2.ZERO
		aim_renderer.clear_aim()
		if not cancel_hint_panel.visible:
			cancel_hint_panel.visible = true
			HapticsManager.tap()
		return

	cancel_hint_panel.visible = false
	var dir := Vector2.UP

	if aim_mode == "slingshot":
		var pull_vec := pos - SHOOTER_POS
		var pull_dist := pull_vec.length()

		# If user drags UP above the shooter bubble while holding, switch smoothly to direct aim
		if pull_vec.y < -95.0:
			aim_mode = "direct"
			cur_preview.position = Vector2.ZERO
			aim_renderer.update_slingshot(SHOOTER_POS, SHOOTER_POS, false)
			dir = (pos - SHOOTER_POS).normalized()
			aim_valid = true
		else:
			var clamped_pull := pull_vec.limit_length(SLINGSHOT_MAX_PULL)
			if clamped_pull.y < 10.0:
				clamped_pull.y = 10.0
			cur_preview.position = clamped_pull
			aim_renderer.update_slingshot(SHOOTER_POS, SHOOTER_POS + clamped_pull, true)

			if pull_dist < SLINGSHOT_MIN_PULL:
				dir = Vector2.UP
				aim_valid = false
			else:
				dir = (-clamped_pull).normalized()
				aim_valid = true
	else:
		cur_preview.position = Vector2.ZERO
		aim_renderer.update_slingshot(SHOOTER_POS, SHOOTER_POS, false)
		var delta_v := pos - SHOOTER_POS
		if delta_v.y > -40.0:
			delta_v.y = -40.0
		dir = delta_v.normalized()
		aim_valid = true

	if dir.y > -0.18:
		dir.y = -0.18
		dir = dir.normalized()
	aim_dir = dir

	var occupied_pts: Array[Vector2] = []
	for b in grid.values():
		occupied_pts.append(b["node"].position)

	aim_renderer.update_trajectory(
		SHOOTER_POS, aim_dir,
		PLAYFIELD_LEFT + BUBBLE_RADIUS, PLAYFIELD_RIGHT - BUBBLE_RADIUS,
		ceiling_bar.position.y + 14.0 + BUBBLE_RADIUS,
		occupied_pts, BUBBLE_RADIUS,
		cur_preview.get_fx_color(),
		active_powerup == "aim"
	)


func _fire_bubble() -> void:
	if shots_left <= 0:
		return
	is_shooting = true
	shots_left -= 1
	flying_bounces = 0

	var shot_type := "n"
	var shot_col := cur_color
	if active_powerup == "bomb":
		shot_type = "b"
		shot_col = -1
		SaveManager.use_powerup("bomb")
		active_powerup = ""
	elif active_powerup == "swap":
		shot_type = "r"
		shot_col = -1
		SaveManager.use_powerup("swap")
		active_powerup = ""
	elif active_powerup == "aim":
		SaveManager.use_powerup("aim")
		active_powerup = ""

	flying_node = BubbleNode.new()
	flying_node.setup(shot_col, shot_type, BUBBLE_RADIUS * 2.0)
	flying_node.position = SHOOTER_POS
	bubble_layer.add_child(flying_node)
	flying_vel = aim_dir * SHOT_SPEED

	# Cannon recoil animation
	cannon_root.position = SHOOTER_POS - aim_dir * 22.0
	var tw := create_tween().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(cannon_root, "position", SHOOTER_POS, 0.22)

	AudioManager.play_sfx("sfx_shoot")
	HapticsManager.tap()

	cur_color = next_color
	next_color = _pick_smart_color()
	_refresh_shooter_previews()
	_update_hud()


func _step_projectile(delta: float) -> void:
	var sub_steps := 4
	var dt := delta / float(sub_steps)
	var min_x := PLAYFIELD_LEFT + BUBBLE_RADIUS
	var max_x := PLAYFIELD_RIGHT - BUBBLE_RADIUS
	var top_y := ceiling_bar.position.y + 14.0 + BUBBLE_RADIUS
	var hit_sq := (BUBBLE_RADIUS * 1.78) * (BUBBLE_RADIUS * 1.78)

	for _i in range(sub_steps):
		flying_node.position += flying_vel * dt
		if flying_node.position.x <= min_x:
			flying_node.position.x = min_x
			flying_vel.x = absf(flying_vel.x)
			flying_bounces += 1
			AudioManager.play_sfx("sfx_bounce", 1.0 + flying_bounces * 0.08)
			HapticsManager.tap()
		elif flying_node.position.x >= max_x:
			flying_node.position.x = max_x
			flying_vel.x = -absf(flying_vel.x)
			flying_bounces += 1
			AudioManager.play_sfx("sfx_bounce", 1.0 + flying_bounces * 0.08)
			HapticsManager.tap()

		var collided := flying_node.position.y <= top_y
		if not collided:
			for b in grid.values():
				if flying_node.position.distance_squared_to(b["node"].position) <= hit_sq:
					collided = true
					break
		if collided:
			_land_projectile()
			return


func _land_projectile() -> void:
	is_shooting = false
	var cell := hex.world_to_nearest_empty(flying_node.position, grid)
	var snapped_pos := hex.cell_to_world(cell.x, cell.y)
	flying_node.position = snapped_pos
	flying_node.grid_cell = cell
	flying_node.play_snap_bounce()

	var shot_type := flying_node.bubble_type
	var shot_col := flying_node.color_id
	grid[cell] = {"color": shot_col, "type": shot_type, "node": flying_node}
	flying_node = null

	_resolve_impact(cell, shot_col, shot_type)


func _resolve_impact(cell: Vector2i, shot_col: int, shot_type: String) -> void:
	var to_pop := {}
	var is_bomb_shot := (shot_type == "b")
	var is_rainbow_shot := (shot_type == "r")

	if is_bomb_shot:
		for bc in hex.get_ring2(cell.x, cell.y):
			if grid.has(bc):
				to_pop[bc] = true
		AudioManager.play_sfx("sfx_bomb")
		HapticsManager.heavy()
		shake_strength = 22.0
		_spawn_shockwave(hex.cell_to_world(cell.x, cell.y), Color("#FF4500"), 240.0)
	elif is_rainbow_shot:
		AudioManager.play_sfx("sfx_rainbow")
		to_pop[cell] = true
		var seen_cols := {}
		for nb in hex.get_neighbors(cell.x, cell.y):
			if grid.has(nb) and grid[nb]["type"] == "n":
				seen_cols[int(grid[nb]["color"])] = true
		for c_id in seen_cols.keys():
			var cl := hex.find_match_cluster(cell, grid, int(c_id))
			if cl.size() >= 2:
				for p in cl:
					to_pop[p] = true
	else:
		var cl := hex.find_match_cluster(cell, grid, shot_col)
		if cl.size() >= 3:
			for p in cl:
				to_pop[p] = true

	var bomb_queue: Array[Vector2i] = []
	var check_list := to_pop.keys()
	check_list.append(cell)
	for c_pos in check_list:
		for nb in hex.get_neighbors(c_pos.x, c_pos.y):
			if grid.has(nb) and grid[nb]["type"] == "b" and not to_pop.has(nb):
				to_pop[nb] = true
				bomb_queue.append(nb)

	while not bomb_queue.is_empty():
		var bc: Vector2i = bomb_queue.pop_front()
		AudioManager.play_sfx("sfx_bomb")
		HapticsManager.heavy()
		shake_strength = maxf(shake_strength, 20.0)
		_spawn_shockwave(hex.cell_to_world(bc.x, bc.y), Color("#FF6B00"), 220.0)
		for r2 in hex.get_ring2(bc.x, bc.y):
			if grid.has(r2) and not to_pop.has(r2):
				if grid[r2]["type"] == "b":
					bomb_queue.append(r2)
				to_pop[r2] = true

	var popped_count := 0
	var boss_damaged := 0
	if not to_pop.is_empty():
		combo_streak += 1
		var adj_seen := {}
		for pc in to_pop.keys():
			for nb in hex.get_neighbors(pc.x, pc.y):
				if grid.has(nb) and not to_pop.has(nb) and not adj_seen.has(nb):
					adj_seen[nb] = true
					var t: String = grid[nb]["type"]
					if t == "i":
						grid[nb]["type"] = "n"
						grid[nb]["node"].crack_special()
						AudioManager.play_sfx("sfx_ice_crack")
					elif t == "l":
						grid[nb]["type"] = "n"
						grid[nb]["node"].crack_special()
						AudioManager.play_sfx("sfx_lock_break")
					elif t == "B":
						boss_damaged += 1

		var idx := 0
		for pc in to_pop.keys():
			if not grid.has(pc):
				continue
			if grid[pc]["type"] == "B":
				boss_damaged += 2
				continue
			var n: BubbleNode = grid[pc]["node"]
			var fx_col := n.get_fx_color()
			_spawn_pop_burst(n.position, fx_col)
			n.play_pop(idx * 0.022)
			grid.erase(pc)
			popped_count += 1
			idx += 1

		AudioManager.play_pop_combo(combo_streak)
		if popped_count >= 5 or combo_streak >= 3:
			HapticsManager.combo()
			shake_strength = maxf(shake_strength, 11.0)
		else:
			HapticsManager.pop()

		var bank_mult := 1.5 if flying_bounces > 0 else 1.0
		var gained := int(popped_count * 100 * (1.0 + (combo_streak - 1) * 0.25) * bank_mult)
		score += gained
		if flying_bounces > 0:
			_spawn_floating_text(hex.cell_to_world(cell.x, cell.y), "BANK SHOT! +%d" % gained, Color("#00F5FF"))
		elif combo_streak >= 2:
			_spawn_floating_text(hex.cell_to_world(cell.x, cell.y), "COMBO x%d! +%d" % [combo_streak, gained], Color("#FFD700"))
		else:
			_spawn_floating_text(hex.cell_to_world(cell.x, cell.y), "+%d" % gained, Color.WHITE)
	else:
		combo_streak = 0
		for nb in hex.get_neighbors(cell.x, cell.y):
			if grid.has(nb) and grid[nb]["type"] == "s":
				AudioManager.play_sfx("sfx_stone_clink")
				break

	var floating := hex.find_floating(grid)
	var dropped_count := 0
	for fc in floating:
		if not grid.has(fc) or grid[fc]["type"] == "B":
			continue
		var n: BubbleNode = grid[fc]["node"]
		n.start_drop()
		grid.erase(fc)
		dropped_count += 1

	if dropped_count > 0:
		AudioManager.play_sfx("sfx_drop")
		var drop_pts := dropped_count * 220
		score += drop_pts
		_spawn_floating_text(Vector2(540, 820), "SUPER DROP x%d! +%d" % [dropped_count, drop_pts], Color("#39FF14"))
		if is_boss and dropped_count >= 3:
			boss_damaged += 1

	if is_boss and boss_damaged > 0:
		boss_hp = maxi(0, boss_hp - boss_damaged)
		AudioManager.play_sfx("sfx_boss_hit")
		HapticsManager.heavy()
		shake_strength = maxf(shake_strength, 16.0)
		if grid.has(boss_cell):
			_spawn_shockwave(grid[boss_cell]["node"].position, Color("#FF2A85"), 200.0)

	if ceiling_interval > 0:
		shots_taken_since_drop += 1
		if shots_taken_since_drop >= ceiling_interval:
			shots_taken_since_drop = 0
			_descend_ceiling()

	_update_hud()
	_check_win_lose()


func _descend_ceiling() -> void:
	hex.ceiling_offset_rows += 1
	AudioManager.play_sfx("sfx_ceiling_drop")
	HapticsManager.combo()
	shake_strength = maxf(shake_strength, 10.0)
	var new_y := PLAYFIELD_TOP + hex.ceiling_offset_rows * (BUBBLE_RADIUS * HexGrid.SQRT3) - 14.0
	var tw := create_tween().set_parallel(true).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	tw.tween_property(ceiling_bar, "position:y", new_y, 0.32)
	for cell in grid.keys():
		var target_pos := hex.cell_to_world(cell.x, cell.y)
		tw.tween_property(grid[cell]["node"], "position", target_pos, 0.32)


func _check_win_lose() -> void:
	var clearable_left := 0
	var lowest_y := 0.0
	for b in grid.values():
		var t: String = b["type"]
		if t != "s" and t != "B":
			clearable_left += 1
		lowest_y = maxf(lowest_y, b["node"].position.y + BUBBLE_RADIUS)

	if (is_boss and boss_hp <= 0) or (not is_boss and clearable_left == 0) or (is_boss and clearable_left == 0):
		var bonus := shots_left * 350
		score += bonus
		_trigger_win(bonus)
		return

	if lowest_y >= DANGER_LINE_Y:
		_trigger_lose("BUBBLES CROSSED THE LINE!")
		return

	if shots_left <= 0:
		_trigger_lose("OUT OF SHOTS!")


func _on_quick_swap() -> void:
	if is_paused or is_game_over or is_shooting:
		return
	var tmp := cur_color
	cur_color = next_color
	next_color = tmp
	AudioManager.play_sfx("sfx_swap")
	HapticsManager.tap()
	_refresh_shooter_previews()
	# Snappy orbital swap pop animation
	cur_preview.scale = Vector2(0.68, 0.68)
	next_preview.scale = Vector2(0.52, 0.52)
	var tw := create_tween().set_parallel(true).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(cur_preview, "scale", Vector2.ONE, 0.18)
	tw.tween_property(next_preview, "scale", Vector2(0.76, 0.76), 0.18)


func _on_powerup_pressed(kind: String) -> void:
	if is_paused or is_game_over or is_shooting:
		return
	if SaveManager.get_powerup_count(kind) <= 0:
		AudioManager.play_sfx("sfx_ui_back")
		_spawn_floating_text(SHOOTER_POS + Vector2(0, -120), "NO %s LEFT!" % kind.to_upper(), Color("#FF5C8A"))
		return

	if kind == "lightning":
		SaveManager.use_powerup("lightning")
		var max_r := -1
		for cell in grid.keys():
			if grid[cell]["type"] != "B":
				max_r = maxi(max_r, cell.x)
		if max_r >= 0:
			AudioManager.play_sfx("sfx_lightning")
			HapticsManager.heavy()
			shake_strength = 18.0
			var row_y := hex.cell_to_world(max_r, 0).y
			_spawn_lightning_beam(row_y)
			for cell in grid.keys():
				if cell.x == max_r and grid[cell]["type"] != "B":
					var n: BubbleNode = grid[cell]["node"]
					_spawn_pop_burst(n.position, Color("#00F5FF"))
					n.play_pop(0.0)
					grid.erase(cell)
					score += 150
			for fc in hex.find_floating(grid):
				if grid.has(fc) and grid[fc]["type"] != "B":
					grid[fc]["node"].start_drop()
					grid.erase(fc)
					score += 200
			_update_hud()
			_check_win_lose()
		return

	active_powerup = "" if active_powerup == kind else kind
	AudioManager.play_sfx("sfx_ui_tap")
	HapticsManager.tap()
	_refresh_shooter_previews()
	_update_hud()


func _spawn_pop_burst(pos: Vector2, col: Color) -> void:
	for i in range(8):
		var p := ColorRect.new()
		p.size = Vector2(12, 12)
		p.position = pos - Vector2(6, 6)
		p.color = col
		p.mouse_filter = Control.MOUSE_FILTER_IGNORE
		fx_layer.add_child(p)
		var ang := (float(i) / 8.0) * TAU + randf_range(-0.2, 0.2)
		var dist := randf_range(55.0, 125.0)
		var tw := create_tween().set_parallel(true)
		tw.tween_property(p, "position", pos + Vector2(cos(ang), sin(ang)) * dist, 0.28).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
		tw.tween_property(p, "modulate:a", 0.0, 0.28)
		tw.tween_property(p, "scale", Vector2(0.1, 0.1), 0.28)
		tw.chain().tween_callback(p.queue_free)


func _spawn_shockwave(pos: Vector2, col: Color, max_r: float) -> void:
	var ring := Node2D.new()
	ring.position = pos
	fx_layer.add_child(ring)
	var poly := Line2D.new()
	poly.width = 8.0
	poly.default_color = col
	for i in range(33):
		var a := (float(i) / 32.0) * TAU
		poly.add_point(Vector2(cos(a), sin(a)) * 20.0)
	ring.add_child(poly)
	var target_scale := max_r / 20.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(ring, "scale", Vector2(target_scale, target_scale), 0.34).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(ring, "modulate:a", 0.0, 0.34)
	tw.chain().tween_callback(ring.queue_free)


func _spawn_lightning_beam(y_pos: float) -> void:
	var beam := ColorRect.new()
	beam.position = Vector2(PLAYFIELD_LEFT, y_pos - 22.0)
	beam.size = Vector2(PLAYFIELD_RIGHT - PLAYFIELD_LEFT, 44.0)
	beam.color = Color("#7DF9FF", 0.92)
	beam.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fx_layer.add_child(beam)
	var tw := create_tween()
	tw.tween_property(beam, "modulate:a", 0.0, 0.28)
	tw.tween_callback(beam.queue_free)


func _spawn_floating_text(pos: Vector2, txt: String, col: Color) -> void:
	var l := Label.new()
	l.text = txt
	l.position = pos - Vector2(140, 24)
	l.size = Vector2(280, 48)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 32)
	l.add_theme_color_override("font_color", col)
	fx_layer.add_child(l)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y - 95.0, 0.75).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "modulate:a", 0.0, 0.75)
	tw.chain().tween_callback(l.queue_free)


func _trigger_win(bonus: int) -> void:
	is_game_over = true
	AudioManager.play_sfx("sfx_win")
	AudioManager.set_tension_mode(false)
	HapticsManager.heavy()

	var stars := 1
	if score >= int(star_thresholds[2]):
		stars = 3
	elif score >= int(star_thresholds[1]):
		stars = 2

	var rewards := SaveManager.record_level_win(level_id, score, stars, is_boss)
	var reward_txt := ""
	if not rewards.is_empty():
		reward_txt = "\nREWARD EARNED: " + ", ".join(rewards.keys()).to_upper()

	_show_popup(
		"LEVEL %d CLEARED!" % level_id,
		"STARS: %s\nSCORE: %d  (Shot Bonus +%d)%s" % ["★".repeat(stars) + "☆".repeat(3 - stars), score, bonus, reward_txt],
		Color("#00F5FF"),
		[
			["NEXT LEVEL", Color("#059669"), func():
				LevelData.selected_level_id = mini(500, level_id + 1)
				get_tree().reload_current_scene()
			],
			["WORLD MAP", Color("#334155"), func():
				get_tree().change_scene_to_file("res://scenes/WorldMap.tscn")
			],
		]
	)


func _trigger_lose(reason: String) -> void:
	is_game_over = true
	SaveManager.consume_life()
	AudioManager.play_sfx("sfx_lose")
	AudioManager.set_tension_mode(false)
	HapticsManager.heavy()

	var lives_rem := SaveManager.get_lives()
	_show_popup(
		"LEVEL FAILED",
		"%s\nSCORE: %d\nLIVES REMAINING: %d / 5" % [reason, score, lives_rem],
		Color("#FF2A85"),
		[
			["RETRY" if lives_rem > 0 else "REFILL & RETRY", Color("#DC2626"), func():
				if SaveManager.get_lives() <= 0:
					SaveManager.refill_lives()
				get_tree().reload_current_scene()
			],
			["WORLD MAP", Color("#334155"), func():
				get_tree().change_scene_to_file("res://scenes/WorldMap.tscn")
			],
		]
	)


func _on_pause_pressed() -> void:
	if is_game_over:
		return
	is_paused = true
	_reset_touch_state()
	AudioManager.play_sfx("sfx_ui_tap")
	AudioManager.set_paused_muffle(true)
	_show_popup(
		"PAUSED",
		"Level %d • %s" % [level_id, world_cfg.get("name", "")],
		Color("#A855F7"),
		[
			["RESUME", Color("#059669"), func():
				_clear_popups()
				is_paused = false
				AudioManager.set_paused_muffle(false)
			],
			["RESTART", Color("#D97706"), func():
				AudioManager.set_paused_muffle(false)
				get_tree().reload_current_scene()
			],
			["WORLD MAP", Color("#334155"), func():
				AudioManager.set_paused_muffle(false)
				get_tree().change_scene_to_file("res://scenes/WorldMap.tscn")
			],
		]
	)


func _clear_popups() -> void:
	for c in popup_root.get_children():
		c.queue_free()
	popup_root.mouse_filter = Control.MOUSE_FILTER_IGNORE


func _show_popup(title: String, body: String, accent: Color, buttons: Array) -> void:
	_clear_popups()
	popup_root.mouse_filter = Control.MOUSE_FILTER_STOP

	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.02, 0.03, 0.08, 0.78)
	popup_root.add_child(dim)

	var card := PanelContainer.new()
	card.position = Vector2(110, 560)
	card.size = Vector2(860, 680)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.06, 0.08, 0.18, 0.96)
	sb.corner_radius_top_left = 32
	sb.corner_radius_top_right = 32
	sb.corner_radius_bottom_left = 32
	sb.corner_radius_bottom_right = 32
	sb.border_width_left = 3
	sb.border_width_top = 3
	sb.border_width_right = 3
	sb.border_width_bottom = 3
	sb.border_color = accent
	sb.content_margin_left = 44
	sb.content_margin_right = 44
	sb.content_margin_top = 48
	sb.content_margin_bottom = 48
	card.add_theme_stylebox_override("panel", sb)
	popup_root.add_child(card)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 28)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	card.add_child(vb)

	var t_lbl := Label.new()
	t_lbl.text = title
	t_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t_lbl.add_theme_font_size_override("font_size", 50)
	t_lbl.add_theme_color_override("font_color", accent)
	vb.add_child(t_lbl)

	var b_lbl := Label.new()
	b_lbl.text = body
	b_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	b_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD
	b_lbl.add_theme_font_size_override("font_size", 32)
	b_lbl.add_theme_color_override("font_color", Color.WHITE)
	vb.add_child(b_lbl)

	for bdef in buttons:
		var btn := _make_styled_button(bdef[0], Vector2(680, 92), bdef[1], 32)
		var cb: Callable = bdef[2]
		btn.pressed.connect(func():
			AudioManager.play_sfx("sfx_ui_tap")
			HapticsManager.tap()
			cb.call()
		)
		vb.add_child(btn)

	card.scale = Vector2(0.82, 0.82)
	card.pivot_offset = card.size * 0.5
	var tw := create_tween().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(card, "scale", Vector2.ONE, 0.28)
