extends Node

const LEVELS_PATH := "res://data/levels.json"

var worlds: Array = []
var levels: Array = []
var selected_level_id: int = 1


func _ready() -> void:
	_load_levels()


func _load_levels() -> void:
	if not FileAccess.file_exists(LEVELS_PATH):
		push_error("Missing levels.json at " + LEVELS_PATH)
		return
	var f := FileAccess.open(LEVELS_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) == TYPE_DICTIONARY:
		worlds = parsed.get("worlds", [])
		levels = parsed.get("levels", [])


func get_total_levels() -> int:
	return levels.size()


func get_level(level_id: int) -> Dictionary:
	var idx := clampi(level_id - 1, 0, max(0, levels.size() - 1))
	if levels.is_empty():
		return {}
	return levels[idx]


func get_world(world_id: int) -> Dictionary:
	var idx := clampi(world_id - 1, 0, max(0, worlds.size() - 1))
	if worlds.is_empty():
		return {"id": 1, "name": "Cyber Pulse", "palette": ["#080B1E", "#132248", "#00F5FF"], "bgm": "bgm_world_cyber.ogg"}
	return worlds[idx]


func get_world_for_level(level_id: int) -> Dictionary:
	var wid := ((clampi(level_id, 1, 500) - 1) / 50) + 1
	return get_world(wid)
