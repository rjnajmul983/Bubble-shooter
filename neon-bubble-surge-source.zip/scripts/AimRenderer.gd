class_name AimRenderer
extends Node2D

var is_aiming: bool = false
var points: PackedVector2Array = PackedVector2Array()
var aim_color: Color = Color("#00F0FF")
var extended_guide: bool = false
var _flow_offset: float = 0.0


func _process(delta: float) -> void:
	if is_aiming:
		_flow_offset = fmod(_flow_offset + delta * 140.0, 28.0)
		queue_redraw()


func update_trajectory(start_pos: Vector2, dir: Vector2, left_x: float, right_x: float, top_y: float, grid_positions: Array[Vector2], bubble_radius: float, col: Color, is_extended: bool) -> void:
	is_aiming = true
	aim_color = col
	extended_guide = is_extended
	points.clear()

	var cur := start_pos
	var v := dir.normalized()
	if v.y > -0.18:
		v.y = -0.18
		v = v.normalized()

	var max_bounces := 3 if is_extended else 1
	var max_dist := 2400.0 if is_extended else 1150.0
	var step := 14.0
	var traveled := 0.0
	var bounces := 0
	var hit_rad_sq := (bubble_radius * 1.72) * (bubble_radius * 1.72)

	points.append(cur)
	while traveled < max_dist:
		var nxt := cur + v * step
		if nxt.x <= left_x:
			nxt.x = left_x + (left_x - nxt.x)
			v.x = absf(v.x)
			bounces += 1
			points.append(Vector2(left_x, nxt.y))
			if bounces > max_bounces:
				break
		elif nxt.x >= right_x:
			nxt.x = right_x - (nxt.x - right_x)
			v.x = -absf(v.x)
			bounces += 1
			points.append(Vector2(right_x, nxt.y))
			if bounces > max_bounces:
				break

		if nxt.y <= top_y:
			points.append(Vector2(nxt.x, top_y))
			break

		var collided := false
		for gp in grid_positions:
			if nxt.distance_squared_to(gp) <= hit_rad_sq:
				collided = true
				break
		if collided:
			points.append(nxt)
			break

		cur = nxt
		traveled += step
		if int(traveled) % 28 == 0:
			points.append(cur)

	queue_redraw()


func clear_aim() -> void:
	is_aiming = false
	points.clear()
	queue_redraw()


func _draw() -> void:
	if not is_aiming or points.size() < 2:
		return

	# Walk segments and draw glowing flowing dots
	var spacing := 28.0
	var acc := -_flow_offset
	var total_pts := points.size()
	for i in range(total_pts - 1):
		var a := points[i]
		var b := points[i + 1]
		var seg_len := a.distance_to(b)
		if seg_len < 0.01:
			continue
		var d := (b - a) / seg_len
		var t := maxf(0.0, spacing - acc)
		while t <= seg_len:
			var p := a + d * t
			var frac := float(i) / float(max(1, total_pts - 1))
			var alpha := lerpf(0.95, 0.35 if not extended_guide else 0.85, frac)
			var r := lerpf(8.5, 5.0, frac)
			var glow_col := Color(aim_color.r, aim_color.g, aim_color.b, alpha * 0.32)
			var core_col := Color(1.0, 1.0, 1.0, alpha)
			draw_circle(p, r * 2.1, glow_col)
			draw_circle(p, r, Color(aim_color.r, aim_color.g, aim_color.b, alpha))
			draw_circle(p, r * 0.45, core_col)
			t += spacing
		acc = fmod(acc + seg_len, spacing)

	# Draw glowing landing reticle
	var end_p := points[points.size() - 1]
	draw_arc(end_p, 38.0 if extended_guide else 28.0, 0.0, TAU, 32, Color(aim_color.r, aim_color.g, aim_color.b, 0.85), 3.5, true)
	draw_circle(end_p, 7.0, Color(1, 1, 1, 0.9))
