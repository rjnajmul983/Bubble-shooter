class_name BubbleNode
extends Node2D

const COLOR_HEX := [
	Color("#00F0FF"),  # 0: Electric Cyan
	Color("#FF2A85"),  # 1: Plasma Magenta
	Color("#FFB800"),  # 2: Solar Amber
	Color("#39FF14"),  # 3: Hyper Lime
	Color("#A855F7"),  # 4: Cobalt Violet
	Color("#FF3B30"),  # 5: Crimson Nova
	Color("#E2F1FF"),  # 6: Prism Pearl
]

static var _tex_cache: Dictionary = {}

var color_id: int = 0
var bubble_type: String = "n"  # n, i, l, s, b, r, B
var grid_cell: Vector2i = Vector2i(-1, -1)
var is_falling: bool = false
var fall_vel: Vector2 = Vector2.ZERO
var fall_spin: float = 0.0
var _pulse_t: float = 0.0

var base_sprite: Sprite2D
var overlay_sprite: Sprite2D


static func _get_tex(path: String) -> Texture2D:
	if not _tex_cache.has(path):
		if ResourceLoader.exists(path):
			_tex_cache[path] = load(path)
	return _tex_cache.get(path, null)


func _init() -> void:
	base_sprite = Sprite2D.new()
	add_child(base_sprite)
	overlay_sprite = Sprite2D.new()
	add_child(overlay_sprite)


func setup(p_color: int, p_type: String, target_diameter: float = 88.0) -> void:
	color_id = p_color
	bubble_type = p_type
	_pulse_t = randf() * TAU
	_refresh_visuals(target_diameter)


func _refresh_visuals(target_diameter: float = 88.0) -> void:
	overlay_sprite.visible = false
	var tex: Texture2D = null
	match bubble_type:
		"s":
			tex = _get_tex("res://assets/textures/bubble_stone.png")
		"b":
			tex = _get_tex("res://assets/textures/bubble_bomb.png")
		"r":
			tex = _get_tex("res://assets/textures/bubble_rainbow.png")
		"B":
			tex = _get_tex("res://assets/textures/bubble_boss.png")
		_:
			var cid := clampi(color_id, 0, 6)
			tex = _get_tex("res://assets/textures/bubble_%d.png" % cid)

	base_sprite.texture = tex
	if tex != null:
		var s := target_diameter / float(tex.get_width())
		if bubble_type == "B":
			s *= 1.42
		base_sprite.scale = Vector2(s, s)

	if bubble_type == "i":
		var otex := _get_tex("res://assets/textures/overlay_ice.png")
		overlay_sprite.texture = otex
		if otex != null:
			var os := (target_diameter * 1.06) / float(otex.get_width())
			overlay_sprite.scale = Vector2(os, os)
			overlay_sprite.visible = true
	elif bubble_type == "l":
		var otex := _get_tex("res://assets/textures/overlay_lock.png")
		overlay_sprite.texture = otex
		if otex != null:
			var os := (target_diameter * 1.06) / float(otex.get_width())
			overlay_sprite.scale = Vector2(os, os)
			overlay_sprite.visible = true


func get_fx_color() -> Color:
	if bubble_type == "b":
		return Color("#FF4500")
	if bubble_type == "r":
		return Color("#FFFFFF")
	if bubble_type == "s":
		return Color("#94A3B8")
	if bubble_type == "B":
		return Color("#FF007F")
	return COLOR_HEX[clampi(color_id, 0, COLOR_HEX.size() - 1)]


func _process(delta: float) -> void:
	if is_falling:
		fall_vel.y += 2600.0 * delta
		position += fall_vel * delta
		rotation += fall_spin * delta
		if position.x < 48.0:
			position.x = 48.0
			fall_vel.x = absf(fall_vel.x) * 0.65
		elif position.x > 1032.0:
			position.x = 1032.0
			fall_vel.x = -absf(fall_vel.x) * 0.65
		if position.y > 2020.0:
			queue_free()
		return

	if bubble_type == "b" or bubble_type == "r" or bubble_type == "B":
		_pulse_t += delta * (4.2 if bubble_type == "b" else 2.6)
		var pulse := 1.0 + sin(_pulse_t) * 0.055
		scale = Vector2(pulse, pulse)
		if bubble_type == "r":
			base_sprite.rotation += delta * 1.3
		elif bubble_type == "B":
			base_sprite.rotation -= delta * 0.65


func crack_special() -> void:
	if bubble_type == "i" or bubble_type == "l":
		bubble_type = "n"
		_refresh_visuals(88.0)
		var tw := create_tween()
		tw.tween_property(self, "scale", Vector2(1.22, 1.22), 0.08)
		tw.tween_property(self, "scale", Vector2.ONE, 0.12)


func play_snap_bounce() -> void:
	scale = Vector2(1.18, 0.84)
	var tw := create_tween().set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(self, "scale", Vector2.ONE, 0.28)


func play_pop(delay_sec: float = 0.0) -> void:
	var tw := create_tween()
	if delay_sec > 0.0:
		tw.tween_interval(delay_sec)
	tw.tween_property(self, "scale", Vector2(1.32, 1.32), 0.07).set_trans(Tween.TRANS_QUAD)
	tw.parallel().tween_property(self, "modulate:a", 0.0, 0.11)
	tw.tween_callback(queue_free)


func start_drop() -> void:
	is_falling = true
	fall_vel = Vector2(randf_range(-240.0, 240.0), randf_range(-340.0, -140.0))
	fall_spin = randf_range(-7.0, 7.0)
	z_index = 20
