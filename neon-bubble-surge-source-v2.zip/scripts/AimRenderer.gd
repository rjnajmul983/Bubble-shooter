class_name AimRenderer
extends Node2D

var is_aiming: bool = false
var points: PackedVector2Array = PackedVector2Array()
var aim_color: Color = Color("#00F0FF")
var extended_guide: bool = false
var slingshot_active: bool = false
var slingshot_anchor: Vector2 = Vector2.ZERO
var slingshot_pull: Vector2 = Vector2.ZERO
var _flow_offset: float = 0.0
var _pulse: float = 0.0


func _process(delta: float) -> void:
	if is_aiming or slingshot_active:
		_flow_offset = fmod(_flow_offset + delta * 180.0, 26.0)
		_pulse += delta * 6.0
		queue_redraw()


func update_slingshot(anchor: Vector2, pull_pos: Vector2, active: bool) -> void:
	slingshot_active = active
	slingshot_anchor = anchor
	slingshot_pull = pull_pos
	queue_redraw()


func update_trajectory(start_pos: Vector2, dir: Vector2, left_x: float, right_x: float, top_y: float, grid_positions: Array[Vector2], bubble_radius: float, col: Color, is_extended: bool) -> void:
	is_aiming = true
	aim_color = col
	extended_guide = is_extended
	points.clear()

	var cur := start_pos
	var v := dir.normalized()
	if v.y > -0.18:
		v.y = -0.18
		v = v.normalized()

	var max_bounces := 3 if is_extended else 2
	var max_dist := 2500.0 if is_extended else 1650.0
	var step := 12.0
	var traveled := 0.0
	var bounces := 0
	var hit_rad_sq := (bubble_radius * 1.74) * (bubble_radius * 1.74)

	points.append(cur)
	while traveled < max_dist:
		var nxt := cur + v * step
		if nxt.x <= left_x:
			nxt.x = left_x + (left_x - nxt.x)
			v.x = absf(v.x)
			bounces += 1
			points.append(Vector2(left_x, nxt.y))
			if bounces > max_bounces:
				break
		elif nxt.x >= right_x:
			nxt.x = right_x - (nxt.x - right_x)
			v.x = -absf(v.x)
			bounces += 1
			points.append(Vector2(right_x, nxt.y))
			if bounces > max_bounces:
				break

		if nxt.y <= top_y:
			points.append(Vector2(nxt.x, top_y))
			break

		var collided := false
		for gp in grid_positions:
			if nxt.distance_squared_to(gp) <= hit_rad_sq:
				collided = true
				break
		if collided:
			points.append(nxt)
			break

		cur = nxt
		traveled += step
		if int(traveled) % 24 == 0:
			points.append(cur)

	queue_redraw()


func clear_aim() -> void:
	is_aiming = false
	slingshot_active = false
	points.clear()
	queue_redraw()


func _draw() -> void:
	# Draw glowing slingshot pull-back tension band when pulling from shooter
	if slingshot_active and slingshot_anchor.distance_to(slingshot_pull) > 6.0:
		var perp := (slingshot_pull - slingshot_anchor).normalized().orthogonal() * 34.0
		var band_col := Color(aim_color.r, aim_color.g, aim_color.b, 0.78)
		var glow_band := Color(aim_color.r, aim_color.g, aim_color.b, 0.28)
		draw_line(slingshot_anchor + perp, slingshot_pull, glow_band, 14.0, true)
		draw_line(slingshot_anchor - perp, slingshot_pull, glow_band, 14.0, true)
		draw_line(slingshot_anchor + perp, slingshot_pull, band_col, 5.0, true)
		draw_line(slingshot_anchor - perp, slingshot_pull, band_col, 5.0, true)
		draw_circle(slingshot_anchor + perp, 6.0, Color.WHITE)
		draw_circle(slingshot_anchor - perp, 6.0, Color.WHITE)

	if not is_aiming or points.size() < 2:
		return

	# Subtle continuous neon guide beam underneath dots
	for i in range(points.size() - 1):
		draw_line(points[i], points[i + 1], Color(aim_color.r, aim_color.g, aim_color.b, 0.22), 10.0, true)

	# Animated flowing high-contrast target dots
	var spacing := 26.0
	var acc := -_flow_offset
	var total_pts := points.size()
	for i in range(total_pts - 1):
		var a := points[i]
		var b := points[i + 1]
		var seg_len := a.distance_to(b)
		if seg_len < 0.01:
			continue
		var d := (b - a) / seg_len
		var t := maxf(0.0, spacing - acc)
		while t <= seg_len:
			var p := a + d * t
			var frac := float(i) / float(max(1, total_pts - 1))
			var alpha := lerpf(1.0, 0.55 if not extended_guide else 0.92, frac)
			var r := lerpf(9.5, 5.5, frac)
			draw_circle(p, r * 2.2, Color(aim_color.r, aim_color.g, aim_color.b, alpha * 0.34))
			draw_circle(p, r, Color(aim_color.r, aim_color.g, aim_color.b, alpha))
			draw_circle(p, r * 0.48, Color(1.0, 1.0, 1.0, alpha))
			t += spacing
		acc = fmod(acc + seg_len, spacing)

	# Pulsing target landing ring + crosshair at impact point
	var end_p := points[points.size() - 1]
	var ring_r := (42.0 if extended_guide else 34.0) + sin(_pulse) * 3.5
	draw_circle(end_p, ring_r, Color(aim_color.r, aim_color.g, aim_color.b, 0.16))
	draw_arc(end_p, ring_r, 0.0, TAU, 36, Color(aim_color.r, aim_color.g, aim_color.b, 0.95), 4.5, true)
	draw_arc(end_p, ring_r * 0.55, 0.0, TAU, 24, Color(1.0, 1.0, 1.0, 0.85), 2.5, true)
	draw_circle(end_p, 7.0, Color.WHITE)
