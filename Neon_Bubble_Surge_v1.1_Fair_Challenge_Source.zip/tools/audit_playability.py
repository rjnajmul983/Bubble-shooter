#!/usr/bin/env python3
"""Physics-aware gameplay audit for Neon Bubble Surge.
Mirrors GameController + HexGrid collision, snap, match, bomb, ice/lock and boss rules.
An angle sweep supplies physically reachable shot destinations. This is a constructive
witness finder, not a proof that every player route is winnable.
"""
from __future__ import annotations
import json, math, random, argparse, sys
from pathlib import Path
from collections import deque
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from generate_levels import get_neighbors, get_ring2, find_floating, remaining_clearable, cols_for_row

R=44.0
LEFT,RIGHT=100.0,980.0
START=(540.,1575.)
TOP=230.+R+14.
HIT=1.78*R
SQ3=math.sqrt(3.)
ANGLES=np.linspace(-1.38,1.38,211)

def center(rc):
    row,col=rc
    return np.array((56.+R+2*R*col+(R if row%2 else 0), 230.+R+row*R*SQ3))

def snap(pt, grid):
    row=max(0, round((float(pt[1])-230.-R)/(R*SQ3)))
    best=None;dist=float('inf')
    for rr in range(max(0,row-2),row+3):
        for cc in range(cols_for_row(rr)):
            key=(rr,cc)
            if key in grid:continue
            p=center(key)
            d=np.sum((p-pt)**2)
            if d<dist:best=key;dist=d
    return best

def landing_spots(g):
    """Angle sweep of the same point-to-circle and wall collision geometry."""
    if not g:
        return {(0,5):0.0}
    keys=list(g)
    coords=np.array([center(k) for k in keys])
    res={}
    for angle in ANGLES:
        pos=np.array(START)
        direction=np.array((math.sin(angle), -math.cos(angle)))
        for _ in range(4):
            wallx=RIGHT if direction[0]>0 else LEFT
            wallt=((wallx-pos[0])/direction[0]) if abs(direction[0])>1e-9 else 1e12
            top_t=(TOP-pos[1])/direction[1] if direction[1]<-1e-6 else 1e12
            rel=coords-pos
            projection=rel@direction
            perp_sq=np.maximum(0.,np.sum(rel*rel,axis=1)-projection**2)
            allowed=perp_sq <= HIT**2
            d=np.where(allowed, projection-np.sqrt(np.maximum(0.,HIT**2-perp_sq)), np.inf)
            d=np.where(d>=-0.00001,d,np.inf)
            t=float(np.min(d))
            if t<=min(wallt,top_t)+0.0001:
                destination=pos+direction*max(0.,t)
                spot=snap(destination,g)
                if spot is not None:res.setdefault(spot,float(angle))
                break
            if top_t<=wallt:
                destination=pos+direction*top_t
                spot=snap(destination,g)
                if spot is not None:res.setdefault(spot,float(angle))
                break
            if wallt>=1e11:break
            pos=pos+direction*wallt
            direction[0]*=-1.
    return res

def simulate(g,spot,col,hp,shot_type="n"):
    g=g.copy()
    g[spot]=(col,shot_type)
    to_pop=set()
    if shot_type == 'b':
        to_pop = {p for p in get_ring2(*spot) if p in g}
    else:
        seen={spot};queue=deque([spot]);cluster={spot}
        while queue:
            cell=queue.popleft()
            for nb in get_neighbors(*cell):
                if nb not in g or nb in seen: continue
                cc,typ=g[nb]
                if (typ=='n' and cc==col) or typ=='r':
                    seen.add(nb);cluster.add(nb);queue.append(nb)
        if len(cluster)>=3:to_pop|=cluster
    bombq=deque()
    for cell in list(to_pop)+[spot]:
        for nb in get_neighbors(*cell):
            if nb in g and g[nb][1]=='b' and nb not in to_pop:
                to_pop.add(nb);bombq.append(nb)
    while bombq:
        bc=bombq.popleft()
        for near in get_ring2(*bc):
            if near in g and near not in to_pop:
                if g[near][1]=='b':bombq.append(near)
                to_pop.add(near)
    dmg=0
    if to_pop:
        adj={nb for pc in to_pop for nb in get_neighbors(*pc) if nb in g and nb not in to_pop}
        for n in adj:
            c,t=g[n]
            if t in ('i','l'):g[n]=(c,'n')
            elif t=='B':dmg+=1
        for pc in to_pop:
            if pc not in g:continue
            if g[pc][1]=='B':dmg+=2
            else:del g[pc]
    popped=len(to_pop)
    floating=find_floating(g)
    dropped=0
    for cell in floating:
        if g[cell][1]!='B':del g[cell];dropped+=1
    if dropped>=3 and hp>0:dmg+=1
    return g,popped,dropped,max(0,hp-dmg)

def solved(g,hp,is_boss):
    return (hp<=0 if is_boss else False) or remaining_clearable(g)==0

def seek(level, max_steps=None, seed=0, queue_mode=False):
    """Greedy move search. In queue_mode, choices restricted to current/next pair."""
    g={(e['r'],e['c']):(e['color'],e['type']) for e in level['grid']}
    hp=level['boss_hp'];is_boss=level['is_boss']
    original=len(g)
    max_steps=max_steps or min(95,max(level['shots']+15,60))
    trace=[];stagnant=0
    prng=random.Random(level['id']*10013+seed)
    prev_clear=remaining_clearable(g)
    for step in range(max_steps):
        if solved(g,hp,is_boss):return True,trace
        destinations=landing_spots(g)
        if not destinations:return False,trace
        available=sorted({c for c,t in g.values() if t in ('n','i','l') and c>=0})
        if not available:available=list(range(level['colors']))
        must_break=stagnant>=2 or not any(t=='n' for c,t in g.values())
        options=[]
        for col in [-1] if must_break else available:
            for spot,angle in destinations.items():
                # skip too many unproductive shots
                ng,popped,dropped,nhp=simulate(g,spot,col,hp, 'b' if must_break else 'n')
                clear=remaining_clearable(ng)
                cracked=sum(1 for k,v in ng.items() if k in g and g[k][1] in ('i','l') and v[1]=='n')
                cost=clear-prev_clear
                dmg=hp-nhp
                # match high impact while making some room for setup
                val=(prev_clear-clear)*3.2+dmg*22 + cracked*2.3 + dropped*1.6 + prng.random()*0.65
                val-=spot[0]*0.07
                if popped<=0 and dropped<=0 and dmg<=0:val-=6+stagnant*0.65
                if len(ng)>original+35:val-=2
                options.append((val, col, spot, angle, ng,popped,dropped,nhp,clear))
        if not options:return False,trace
        options.sort(key=lambda v:v[0], reverse=True)
        chosen=options[0]
        _, col, spot, angle, ng,popped,dropped,nhp,clear=chosen
        if not popped and not dropped and hp==nhp:
            stagnant+=1
            if stagnant>=8:return False,trace
        else:stagnant=0
        trace.append({'color':col,'type':'b' if must_break else 'n','target':list(spot),'angle':round(angle,5),'popped':popped,'dropped':dropped,'remaining':clear,'boss_hp':nhp})
        g,hp,prev_clear=ng,nhp,clear
    return solved(g,hp,is_boss),trace

def main():
    arg=argparse.ArgumentParser();arg.add_argument('--levels',nargs='*',type=int);arg.add_argument('--start',type=int,default=1);arg.add_argument('--limit',type=int,default=500);arg.add_argument('--attempts',type=int,default=2);arg.add_argument('--output',default='tools/playability_audit.json'); args=arg.parse_args()
    src=json.loads((ROOT/'data/levels.json').read_text())
    levels=src['levels']
    if args.levels:levels=[levels[i-1] for i in args.levels]
    else:levels=levels[args.start-1:args.start-1+args.limit]
    successes=0;reports=[]
    for level in levels:
        outcome=None
        for seed in range(args.attempts):
            ok,path=seek(level,seed=seed)
            if ok:outcome=path;break
        verified=outcome is not None
        successes+=int(verified)
        reports.append({'level':level['id'],'physically_reachable_witness':verified,'shots_used':len(outcome) if verified else None,'budget':level['shots'],'plan':outcome if verified else []})
        if level['id']<=11 or level['id']%25==0:print('Audit level',level['id'], 'verified',verified,'shots',len(outcome) if verified else '-', 'budget',level['shots'],flush=True)
    print('Passed:',successes,'/',len(reports),flush=True)
    (ROOT/args.output).write_text(json.dumps({'verified':successes,'tested':len(reports),'levels':reports},indent=2))

if __name__=='__main__':main()
