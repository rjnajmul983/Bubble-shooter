class_name HexGrid
extends RefCounted

const COLS_EVEN := 11
const COLS_ODD := 10
const SQRT3 := 1.73205080757

var radius: float = 44.0
var origin: Vector2 = Vector2(56.0, 230.0)
# Ceiling movement shifts world Y only. Logical row parity and width cannot
# change when it descends, or balls jump sideways / overlap wall boundaries.
var ceiling_offset_rows: int = 0


func cols_for_row(r: int) -> int:
	return COLS_EVEN if (r % 2 == 0) else COLS_ODD


func is_odd_row(r: int) -> bool:
	return (r % 2) == 1


func cell_to_world(r: int, c: int) -> Vector2:
	var x_shift := radius if is_odd_row(r) else 0.0
	var x := origin.x + c * (radius * 2.0) + x_shift + radius
	var y := origin.y + (r + ceiling_offset_rows) * (radius * SQRT3) + radius
	return Vector2(x, y)


func get_neighbors(r: int, c: int) -> Array[Vector2i]:
	var odd := is_odd_row(r)
	var offsets: Array[Vector2i]
	if not odd:
		offsets = [
			Vector2i(-1, -1), Vector2i(-1, 0),
			Vector2i(0, -1),  Vector2i(0, 1),
			Vector2i(1, -1),  Vector2i(1, 0),
		]
	else:
		offsets = [
			Vector2i(-1, 0), Vector2i(-1, 1),
			Vector2i(0, -1), Vector2i(0, 1),
			Vector2i(1, 0),  Vector2i(1, 1),
		]
	var out: Array[Vector2i] = []
	for o in offsets:
		var nr := r + o.x
		var nc := c + o.y
		if nr >= 0 and nc >= 0 and nc < cols_for_row(nr):
			out.append(Vector2i(nr, nc))
	return out


func get_ring2(r: int, c: int) -> Array[Vector2i]:
	var visited := {Vector2i(r, c): true}
	var frontier: Array[Vector2i] = [Vector2i(r, c)]
	for _step in range(2):
		var nxt: Array[Vector2i] = []
		for cur in frontier:
			for nb in get_neighbors(cur.x, cur.y):
				if not visited.has(nb):
					visited[nb] = true
					nxt.append(nb)
		frontier = nxt
	var out: Array[Vector2i] = []
	for k in visited.keys():
		out.append(k)
	return out


func world_to_nearest_empty(pos: Vector2, occupied: Dictionary) -> Vector2i:
	var est_row := maxi(0, int(round((pos.y - origin.y - radius) / (radius * SQRT3))) - ceiling_offset_rows)
	var best_cell := Vector2i(est_row, 0)
	var best_dist := INF
	for r in range(maxi(0, est_row - 2), est_row + 3):
		var ncols := cols_for_row(r)
		for c in range(ncols):
			var cell := Vector2i(r, c)
			if occupied.has(cell):
				continue
			var d := pos.distance_squared_to(cell_to_world(r, c))
			if d < best_dist:
				best_dist = d
				best_cell = cell
	return best_cell


func find_match_cluster(start: Vector2i, grid: Dictionary, target_color: int) -> Array[Vector2i]:
	var visited := {start: true}
	var queue: Array[Vector2i] = [start]
	var cluster: Array[Vector2i] = [start]
	while not queue.is_empty():
		var cur: Vector2i = queue.pop_front()
		for nb in get_neighbors(cur.x, cur.y):
			if visited.has(nb) or not grid.has(nb):
				continue
			var b: Dictionary = grid[nb]
			var btype: String = b["type"]
			var bcol: int = b["color"]
			if (btype == "n" and bcol == target_color) or btype == "r":
				visited[nb] = true
				cluster.append(nb)
				queue.append(nb)
	return cluster


func find_floating(grid: Dictionary) -> Array[Vector2i]:
	var anchored := {}
	var queue: Array[Vector2i] = []
	for cell in grid.keys():
		if cell.x == 0:
			anchored[cell] = true
			queue.append(cell)
	while not queue.is_empty():
		var cur: Vector2i = queue.pop_front()
		for nb in get_neighbors(cur.x, cur.y):
			if grid.has(nb) and not anchored.has(nb):
				anchored[nb] = true
				queue.append(nb)
	var floating: Array[Vector2i] = []
	for cell in grid.keys():
		if not anchored.has(cell):
			floating.append(cell)
	return floating
