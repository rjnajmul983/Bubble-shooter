extends Control

var current_world_id: int = 1
var bg_mat: ShaderMaterial
var lbl_world: Label
var grid_container: GridContainer
var world_tabs: HBoxContainer


func _ready() -> void:
	var unlocked: int = int(SaveManager.data.get("unlocked_level", 1))
	current_world_id = ((clampi(unlocked, 1, 500) - 1) / 50) + 1
	AudioManager.play_bgm("bgm_menu.ogg", 0.5)
	_build_ui()
	_select_world(current_world_id)


func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg_mat = ShaderMaterial.new()
	bg_mat.shader = load("res://assets/shaders/neon_bg.gdshader")
	bg.material = bg_mat
	add_child(bg)

	var root_v := VBoxContainer.new()
	root_v.set_anchors_preset(Control.PRESET_FULL_RECT)
	root_v.offset_left = 36
	root_v.offset_right = -36
	root_v.offset_top = 48
	root_v.offset_bottom = -44
	root_v.add_theme_constant_override("separation", 20)
	add_child(root_v)

	# Top bar
	var top_h := HBoxContainer.new()
	top_h.add_theme_constant_override("separation", 18)
	root_v.add_child(top_h)

	var btn_back := _make_btn("< MENU", Color("#334155"), Vector2(180, 76), 28)
	btn_back.pressed.connect(func():
		AudioManager.play_sfx("sfx_ui_back")
		get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
	)
	top_h.add_child(btn_back)

	lbl_world = Label.new()
	lbl_world.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lbl_world.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_world.add_theme_font_size_override("font_size", 36)
	lbl_world.add_theme_color_override("font_color", Color("#00F5FF"))
	top_h.add_child(lbl_world)

	# World selector strip (10 worlds)
	var tab_scroll := ScrollContainer.new()
	tab_scroll.custom_minimum_size = Vector2(0, 92)
	tab_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root_v.add_child(tab_scroll)

	world_tabs = HBoxContainer.new()
	world_tabs.add_theme_constant_override("separation", 12)
	tab_scroll.add_child(world_tabs)

	for w in range(1, 11):
		var wb := _make_btn("W%d" % w, Color("#1E293B"), Vector2(118, 76), 28)
		var wid := w
		wb.pressed.connect(func():
			AudioManager.play_sfx("sfx_ui_tap")
			HapticsManager.tap()
			_select_world(wid)
		)
		world_tabs.add_child(wb)

	# 50-level scrollable grid for selected world
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root_v.add_child(scroll)

	grid_container = GridContainer.new()
	grid_container.columns = 5
	grid_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid_container.add_theme_constant_override("h_separation", 16)
	grid_container.add_theme_constant_override("v_separation", 16)
	scroll.add_child(grid_container)


func _select_world(world_id: int) -> void:
	current_world_id = clampi(world_id, 1, 10)
	var wcfg := LevelData.get_world(current_world_id)
	var pal: Array = wcfg.get("palette", ["#080B1E", "#132248", "#00F5FF"])
	bg_mat.set_shader_parameter("color_top", Color(pal[0]))
	bg_mat.set_shader_parameter("color_bot", Color(pal[1]))
	bg_mat.set_shader_parameter("accent_color", Color(pal[2]))

	var start_lv := (current_world_id - 1) * 50 + 1
	var end_lv := current_world_id * 50
	var world_stars := 0
	for lv in range(start_lv, end_lv + 1):
		world_stars += SaveManager.get_level_stars(lv)
	lbl_world.text = "W%d: %s  (★ %d/150)" % [current_world_id, wcfg.get("name", ""), world_stars]

	for c in grid_container.get_children():
		c.queue_free()

	var unlocked: int = int(SaveManager.data.get("unlocked_level", 1))
	for lv in range(start_lv, end_lv + 1):
		var is_open := lv <= unlocked
		var is_boss := (lv % 10 == 0)
		var stars := SaveManager.get_level_stars(lv)
		var col := Color("#1E293B")
		if is_open:
			col = Color("#9D174D") if is_boss else (Color("#047857") if stars > 0 else Color("#2563EB"))

		var tag := "\nBOSS" if is_boss else ""
		var star_line := "\n" + ("★".repeat(stars) + "☆".repeat(3 - stars)) if is_open else "\nLOCKED"
		var b := _make_btn("%d%s%s" % [lv, tag, star_line], col, Vector2(182, 134), 24)
		b.disabled = not is_open
		var chosen := lv
		b.pressed.connect(func():
			AudioManager.play_sfx("sfx_ui_tap")
			HapticsManager.tap()
			LevelData.selected_level_id = chosen
			get_tree().change_scene_to_file("res://scenes/Game.tscn")
		)
		grid_container.add_child(b)


func _make_btn(txt: String, col: Color, min_sz: Vector2, font_sz: int) -> Button:
	var b := Button.new()
	b.text = txt
	b.custom_minimum_size = min_sz
	b.add_theme_font_size_override("font_size", font_sz)
	b.add_theme_color_override("font_color", Color.WHITE)
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	sb.corner_radius_top_left = 18
	sb.corner_radius_top_right = 18
	sb.corner_radius_bottom_left = 18
	sb.corner_radius_bottom_right = 18
	sb.border_width_bottom = 4
	sb.border_color = col.lightened(0.4)
	b.add_theme_stylebox_override("normal", sb)
	var sbh := sb.duplicate()
	sbh.bg_color = col.lightened(0.15)
	b.add_theme_stylebox_override("hover", sbh)
	b.add_theme_stylebox_override("pressed", sbh)
	return b
