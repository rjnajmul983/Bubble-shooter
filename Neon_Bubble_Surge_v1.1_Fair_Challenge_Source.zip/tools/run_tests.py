#!/usr/bin/env python3
"""
Automated Verification & Integrity Test Suite for Neon Bubble Surge
Verifies:
1. All 500 levels exist, have 100% unique layouts, valid grid coordinates, and physics-witness budgets.
2. All 10 worlds have valid themes and existing BGM files.
3. All referenced res:// textures, shaders, scripts, scenes, and audio assets exist on disk.
4. project.godot and export_presets.cfg contain required Android 16 & JSON export settings.
"""

import hashlib
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def assert_true(cond, msg):
    if not cond:
        print(f"[FAIL] {msg}")
        sys.exit(1)
    print(f"[PASS] {msg}")


def test_levels():
    path = os.path.join(ROOT, "data", "levels.json")
    assert_true(os.path.exists(path), "data/levels.json exists")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    worlds = data.get("worlds", [])
    levels = data.get("levels", [])
    assert_true(len(worlds) == 10, f"10 worlds defined (found {len(worlds)})")
    assert_true(len(levels) == 500, f"500 levels defined (found {len(levels)})")

    seen_hashes = set()
    boss_count = 0
    for idx, lv in enumerate(levels, start=1):
        assert lv["id"] == idx, f"Level ID mismatch at {idx}"
        assert 5 <= lv["colors"] <= 7, f"Level {idx} color count out of hard range: {lv['colors']}"
        assert lv["shots"] >= lv["physics_witness_shots"] >= 1, f"Level {idx} invalid shot budget"
        colors = lv.get("witness_colors", [])
        targets = lv.get("witness_targets", [])
        angles = lv.get("witness_angles", [])
        assert len(colors) == len(targets) == len(angles) == lv["physics_witness_shots"], f"Level {idx} malformed witness"
        assert all(c == -1 or 0 <= c < lv["colors"] for c in colors), f"Level {idx} illegal ammo color"
        assert all(isinstance(t, list) and len(t) == 2 and 0 <= t[0] < 30 and 0 <= t[1] < (11 - t[0] % 2) for t in targets), f"Level {idx} invalid target"
        assert all(-1.39 <= a <= 1.39 for a in angles), f"Level {idx} illegal trajectory"
        if lv["ceiling_interval"] > 0:
            assert lv["ceiling_interval"] > len(colors), f"Level {idx} descent can invalidate witness"
        if lv["timer_sec"] > 0:
            assert lv["timer_sec"] >= int(len(colors)*4.0), f"Level {idx} timer too tight"
        assert len(lv["grid"]) >= 25, f"Level {idx} too sparse"
        if lv["is_boss"]:
            boss_count += 1
            assert lv["boss_hp"] >= 6, f"Boss level {idx} HP too low"
        sig = hashlib.sha1(json.dumps(lv["grid"], sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        seen_hashes.add(sig)

    assert_true(len(seen_hashes) == 500, f"All 500 level layouts are 100% unique ({len(seen_hashes)}/500)")
    assert_true(boss_count == 50, f"50 boss encounters verified (every 10th level)")
    assert_true(levels[10]["shots"] >= 25, "Level 11 receives rebalanced ammunition budget")
    assert_true(levels[479]["boss_hp"] == 18, "Level 480 boss HP is calibrated")
    assert_true(data.get("version") == 2, "Version 2 verified-ammo level data loaded")
    print("[PASS] All 500 per-shot reference ammo decks, targets, and budgets validated")

    for w in worlds:
        bgm_path = os.path.join(ROOT, "assets", "audio", w["bgm"])
        assert os.path.exists(bgm_path), f"Missing world BGM: {w['bgm']}"
    print("[PASS] All 10 world BGM tracks exist")


def test_res_references():
    res_pattern = re.compile(r'res://([A-Za-z0-9_./%-]+)')
    checked = 0
    for dirpath, _, filenames in os.walk(ROOT):
        if ".git" in dirpath or "build" in dirpath:
            continue
        for fn in filenames:
            if not fn.endswith((".gd", ".tscn", ".godot", ".cfg")):
                continue
            full = os.path.join(dirpath, fn)
            with open(full, "r", encoding="utf-8") as f:
                content = f.read()
            for m in res_pattern.finditer(content):
                rel = m.group(1)
                if "%" in rel or rel.endswith("/"):
                    continue
                target = os.path.join(ROOT, rel)
                assert os.path.exists(target), f"Broken res:// reference '{rel}' in {fn}"
                checked += 1
    assert_true(checked > 15, f"Verified {checked} res:// asset/scene/script references")


def test_audio_and_textures():
    tex_dir = os.path.join(ROOT, "assets", "textures")
    aud_dir = os.path.join(ROOT, "assets", "audio")
    pngs = [f for f in os.listdir(tex_dir) if f.endswith(".png")]
    wavs = [f for f in os.listdir(aud_dir) if f.endswith(".wav")]
    oggs = [f for f in os.listdir(aud_dir) if f.endswith(".ogg")]
    assert_true(len(pngs) == 13, f"13 bubble/special textures present (found {len(pngs)})")
    assert_true(len(wavs) == 24, f"24 layered WAV SFX present (found {len(wavs)})")
    assert_true(len(oggs) == 5, f"5 looping OGG BGM tracks present (found {len(oggs)})")
    assert_true(os.path.exists(os.path.join(ROOT, "icon.png")), "512x512 icon.png present")


def test_export_config():
    with open(os.path.join(ROOT, "export_presets.cfg"), "r", encoding="utf-8") as f:
        cfg = f.read()
    assert_true('include_filter="*.json"' in cfg, "export_presets.cfg includes *.json for levels.json")
    assert_true("architectures/arm64-v8a=true" in cfg, "arm64-v8a enabled for Android 16")
    assert_true("permissions/vibrate=true" in cfg, "Android haptics vibrate permission enabled")


if __name__ == "__main__":
    test_levels()
    test_audio_and_textures()
    test_res_references()
    test_export_config()
    print("\nALL AUTOMATED TESTS PASSED SUCCESSFULLY!")
