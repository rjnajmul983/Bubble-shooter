extends Node

const SAVE_PATH := "user://neon_bubble_surge_save.json"
const MAX_LIVES := 5
const LIFE_REGEN_SECONDS := 1200  # 20 minutes per life

signal data_changed
signal lives_changed(lives: int, next_regen_sec: int)

var data: Dictionary = {
	"unlocked_level": 1,
	"level_stars": {},     # "1": 3
	"level_scores": {},    # "1": 14500
	"total_score": 0,
	"lives": MAX_LIVES,
	"last_life_ts": 0,
	"powerups": {
		"bomb": 3,
		"lightning": 3,
		"swap": 5,
		"aim": 4,
	},
	"settings": {
		"master_vol": 0.9,
		"music_vol": 0.65,
		"sfx_vol": 0.95,
		"music_muted": false,
		"sfx_muted": false,
		"haptics": true,
		"high_fps": true,
	},
	"last_played_level": 1,
}

var _regen_accum := 0.0


func _ready() -> void:
	load_save()
	_refresh_lives()
	apply_performance_settings()


func _process(delta: float) -> void:
	if int(data["lives"]) < MAX_LIVES:
		_regen_accum += delta
		if _regen_accum >= 1.0:
			_regen_accum = 0.0
			_refresh_lives()


func load_save() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		save_game()
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) == TYPE_DICTIONARY:
		_merge_dict(data, parsed)


func _merge_dict(target: Dictionary, incoming: Dictionary) -> void:
	for k in incoming.keys():
		if target.has(k) and typeof(target[k]) == TYPE_DICTIONARY and typeof(incoming[k]) == TYPE_DICTIONARY:
			_merge_dict(target[k], incoming[k])
		else:
			target[k] = incoming[k]


func save_game() -> void:
	var tmp_path := SAVE_PATH + ".tmp"
	var file := FileAccess.open(tmp_path, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify(data))
	file.close()
	DirAccess.rename_absolute(
		ProjectSettings.globalize_path(tmp_path),
		ProjectSettings.globalize_path(SAVE_PATH)
	)
	data_changed.emit()


func apply_performance_settings() -> void:
	var high_fps: bool = bool(data["settings"].get("high_fps", true))
	Engine.max_fps = 0 if high_fps else 60
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)


func _refresh_lives() -> void:
	var cur_lives: int = int(data["lives"])
	if cur_lives >= MAX_LIVES:
		data["lives"] = MAX_LIVES
		data["last_life_ts"] = 0
		lives_changed.emit(MAX_LIVES, 0)
		return
	var now_ts: int = int(Time.get_unix_time_from_system())
	var last_ts: int = int(data.get("last_life_ts", now_ts))
	if last_ts <= 0:
		data["last_life_ts"] = now_ts
		last_ts = now_ts
	var elapsed: int = max(0, now_ts - last_ts)
	var gained: int = elapsed / LIFE_REGEN_SECONDS
	if gained > 0:
		cur_lives = min(MAX_LIVES, cur_lives + gained)
		data["lives"] = cur_lives
		if cur_lives >= MAX_LIVES:
			data["last_life_ts"] = 0
		else:
			data["last_life_ts"] = last_ts + gained * LIFE_REGEN_SECONDS
		save_game()
	var rem: int = 0 if cur_lives >= MAX_LIVES else max(1, LIFE_REGEN_SECONDS - (now_ts - int(data["last_life_ts"])))
	lives_changed.emit(cur_lives, rem)


func get_lives() -> int:
	_refresh_lives()
	return int(data["lives"])


func get_next_life_seconds() -> int:
	if int(data["lives"]) >= MAX_LIVES:
		return 0
	var now_ts: int = int(Time.get_unix_time_from_system())
	return max(1, LIFE_REGEN_SECONDS - (now_ts - int(data.get("last_life_ts", now_ts))))


func consume_life() -> bool:
	_refresh_lives()
	if int(data["lives"]) <= 0:
		return false
	if int(data["lives"]) == MAX_LIVES:
		data["last_life_ts"] = int(Time.get_unix_time_from_system())
	data["lives"] = int(data["lives"]) - 1
	save_game()
	_refresh_lives()
	return true


func refill_lives() -> void:
	data["lives"] = MAX_LIVES
	data["last_life_ts"] = 0
	save_game()
	_refresh_lives()


func record_level_win(level_id: int, score: int, stars: int, is_boss: bool) -> Dictionary:
	var key := str(level_id)
	var prev_stars: int = int(data["level_stars"].get(key, 0))
	var prev_score: int = int(data["level_scores"].get(key, 0))
	var is_first_clear := (prev_stars == 0)

	if stars > prev_stars:
		data["level_stars"][key] = stars
	if score > prev_score:
		data["total_score"] = int(data["total_score"]) + (score - prev_score)
		data["level_scores"][key] = score
	if level_id >= int(data["unlocked_level"]) and level_id < 500:
		data["unlocked_level"] = level_id + 1
	data["last_played_level"] = min(500, level_id + 1)

	# Reward power-ups on first boss clear or every 5th level 3-star
	var rewards := {}
	if is_first_clear and is_boss:
		add_powerup("bomb", 1)
		add_powerup("lightning", 1)
		rewards["bomb"] = 1
		rewards["lightning"] = 1
	elif stars == 3 and prev_stars < 3 and level_id % 3 == 0:
		var kinds := ["bomb", "lightning", "swap", "aim"]
		var chosen: String = kinds[level_id % kinds.size()]
		add_powerup(chosen, 1)
		rewards[chosen] = 1

	save_game()
	return rewards


func get_level_stars(level_id: int) -> int:
	return int(data["level_stars"].get(str(level_id), 0))


func get_level_score(level_id: int) -> int:
	return int(data["level_scores"].get(str(level_id), 0))


func get_total_stars() -> int:
	var total := 0
	for v in data["level_stars"].values():
		total += int(v)
	return total


func get_powerup_count(kind: String) -> int:
	return int(data["powerups"].get(kind, 0))


func use_powerup(kind: String) -> bool:
	var c := get_powerup_count(kind)
	if c <= 0:
		return false
	data["powerups"][kind] = c - 1
	save_game()
	return true


func add_powerup(kind: String, amount: int) -> void:
	data["powerups"][kind] = get_powerup_count(kind) + amount


func get_setting(key: String, default_val = null):
	return data["settings"].get(key, default_val)


func set_setting(key: String, value) -> void:
	data["settings"][key] = value
	if key == "high_fps":
		apply_performance_settings()
	save_game()
