# Neon Bubble Surge — End-to-End Production Roadmap

## 1. Executive Vision & Design Pillars

**Neon Bubble Surge** is a high-precision, neon-gloss arcade bubble shooter engineered specifically for modern flagship Android devices (12 GB RAM, 256 GB storage, Android 16, 60–120 Hz displays). Rather than shipping a casual clone padded with trivial filler stages, every one of its **500 unique levels** is designed as a tight, solver-verified tactical puzzle that escalates across 10 neon worlds.

- **Zero Easy Filler**: Difficulty starts demanding on Level 1 (5 colors, stone blockers, 2-hit ice shells, tight shot budgets) and escalates relentlessly through locked chains, bomb chains, descending ceilings, countdown timers, 7-color labyrinths, and 50 Boss encounters.
- **Provable Fairness**: An automated hex-grid physics solver plays and validates all 500 levels before packaging; shot budgets are calibrated directly from solver par clears.
- **Tactile Audio-Visual Juice**: Layered, pitch-escalating procedural SFX, dynamic multi-world synthwave music, neon glass shaders, recoil springs, chain-reaction shockwaves, and calibrated Android haptics.
- **Battery-Conscious High-FPS Architecture**: Native 2D batching, zero-allocation hot loops, and lightweight GPU shaders sustain locked 60–120 fps with minimal thermal throttling.

---

## 2. Engine Selection & Justification

### Chosen Engine: **Godot 4.3 (Mobile / GL Compatibility 2D Renderer)**

| Criterion | Godot 4.3 (Chosen) | Unity 6 / 2022 LTS | Custom Native (Kotlin/Canvas) |
| :--- | :--- | :--- | :--- |
| **2D Precision & Performance** | True native 2D coordinate engine, 2D batching, lightweight CanvasItem shaders, 60/120 Hz support | 3D engine adapted for 2D; heavier runtime overhead | Requires building physics, particles, audio bus, and tweening from scratch |
| **APK Size & Battery Draw** | Compact (~25–35 MB APK), low CPU/GPU overhead, minimal idle wake | Larger baseline runtime + IL2CPP overhead | Smallest APK, highest engineering risk |
| **CI/CD & Signed APK Automation** | Free, open-source headless Linux CLI + export templates; zero license keys needed in GitHub Actions | Requires paid/personal license activation secrets in CI | Fast Gradle build, lacks visual shader/audio tooling |
| **Android 16 Compatibility** | Full `arm64-v8a` + `armeabi-v7a` support, Android SDK 35/36 targetable, `Input.vibrate_handheld()` haptics | Supported, heavier Gradle toolchain | Native |

**Verdict**: Godot 4.3 delivers the highest visual/audio polish per watt and produces a clean, reproducible, signed Android APK via GitHub Actions with zero proprietary license barriers.

---

## 3. System Architecture

The codebase follows a decoupled, data-driven singleton + scene architecture:

```text
neon-bubble-surge/
├── project.godot                  # Engine config, autoloads, input & 60/120Hz display settings
├── export_presets.cfg             # Android release APK export preset (arm64-v8a + armeabi-v7a)
├── autoload/
│   ├── SaveManager.gd             # Atomic JSON persistence (stars, scores, lives, power-ups, settings)
│   ├── AudioManager.gd            # 16-voice SFX pool, combo pitch ladder, dynamic world BGM crossfade
│   ├── LevelData.gd               # Indexed loader for 500 levels + 10 World theme configs
│   └── HapticsManager.gd          # Android haptic feedback profiles (pop, combo, bomb, UI)
├── scripts/
│   ├── HexGrid.gd                 # Pure odd-r hex coordinate math, BFS match-3+, roof-anchor flood fill
│   ├── BubbleNode.gd              # Visual bubble entity (glossy texture, special overlays, pop/drop anims)
│   ├── AimRenderer.gd             # Real-time wall-bounce raycast trajectory & aim-guide extension
│   ├── GameController.gd          # Core gameplay loop, shooter physics, boss AI, ceiling descent, timers
│   ├── MainMenu.gd                # Animated neon title screen & navigation
│   ├── WorldMap.gd                # 10-world / 500-level progression browser with star milestones
│   ├── Splash.gd                  # Animated logo intro & preloader
│   └── UIPopups.gd                # Pause, Settings, Win (animated stars), Lose, Power-Up HUD
├── scenes/                        # MainMenu.tscn, WorldMap.tscn, Game.tscn, Splash.tscn
├── data/
│   └── levels.json                # 500 unique, solver-verified level definitions
├── assets/
│   ├── textures/                  # High-DPI glossy neon bubbles, specials, boss core, adaptive icons
│   ├── shaders/                   # neon_bg.gdshader, bubble_gloss.gdshader
│   └── audio/                     # Layered WAV SFX + 5 looping OGG world music tracks
├── tools/
│   ├── generate_levels.py         # Deterministic 500-level generator + automated physics solver
│   └── run_tests.py               # Automated integrity, solver, and project verification suite
└── .github/workflows/
    └── build-apk.yml              # Turnkey GitHub Actions signed APK pipeline
```

---

## 4. Gameplay Mechanics & 500-Level Escalation System

### Core Mechanics
- **Precision Hex Grid**: 11-column odd-r offset hex grid (`cols = 11` even rows, `10` odd rows) with tight collision radii (`0.84 * diameter` snap tolerance) to allow threading bank shots through 1-bubble gaps.
- **Wall-Bounce Raycasting**: Analytical ray-wall reflection against left/right neon bumpers, displaying primary trajectory by default and extended multi-bounce precision with the **Aim Guide** power-up.
- **Match-3+ & Floating Detachment**: BFS cluster detection pops 3+ matching colors; roof-connected flood fill immediately detaches unsupported clusters into physics-driven falling bubbles that award exponential drop bonuses.

### Advanced Mechanics & Hazards
- **Stone Bubbles**: Indestructible by color matches; must be dropped by severing anchors above or shattered via **Bomb** / **Lightning**.
- **Ice Bubbles (2-Hit)**: Encased in crystalline frost; adjacent pops crack the ice on hit 1 and expose the color bubble on hit 2.
- **Locked Bubbles (Chained)**: Bound by titanium energy chains; cannot match until an adjacent pop breaks the lock.
- **Bomb Bubbles (Board & Power-Up)**: Detonate a 2-ring hex blast radius, clearing stone, ice, locks, and damaging bosses.
- **Rainbow Wildcards**: Match any adjacent color cluster simultaneously on impact.
- **Descending Ceilings**: Roof drops one hex row every `N` non-popping (or total) shots, compressing aiming space and triggering hydraulic audio/visual warnings.
- **Countdown Timers**: High-pressure speed stages requiring rapid bank-shot execution.
- **Boss Encounters (Every 10th Level — 50 Bosses)**: Armored Reactor Core anchored at the top with a live HP bar; dropping bubbles beneath it or blasting adjacent clusters drains Boss HP while the boss periodically pulses ice/lock shields.

### 10-World Progression Curve (500 Unique Levels)

| World | Levels | Colors | Signature Hazards & Escalation |
| :--- | :---: | :---: | :--- |
| 1. Cyber Pulse | 1–50 | 5 | Tight shot budgets, Stone pillars, Ice clusters, Bosses every 10th |
| 2. Cryo Prism | 51–100 | 5 | Heavy 2-hit Ice walls, Locked chains, bank-shot funnels |
| 3. Volt Foundry | 101–150 | 5–6 | Embedded Bomb chains, Descending ceilings (every 7 shots) |
| 4. Plasma Rift | 151–200 | 6 | Rainbow pivots, Countdown Timers (75–95s), tight arches |
| 5. Obsidian Vault | 201–250 | 6 | Dense Stone/Lock fortresses requiring anchor-cut drops |
| 6. Hyperion Core | 251–300 | 6 | Accelerated ceiling descent (every 6 shots) + Ice shields |
| 7. Quantum Maze | 301–350 | 7 | 7-color palette, asymmetric corridors, multi-bomb relays |
| 8. Solar Flare | 351–400 | 7 | Simultaneous Timer + Descending Ceiling + Stone/Lock gauntlets |
| 9. Void Singularity | 401–450 | 7 | Razor-thin shot par, deep bank-shot pockets, shielded bosses |
| 10. Astral Apex | 451–500 | 7 | Full-hazard masterclass combining every mechanic & 5 Endgame Bosses |

### Automated Solver Validation
Every generated level is simulated by `tools/generate_levels.py` using a greedy + lookahead beam-search solver that evaluates direct and single-bounce bank shots across the playable hex frontier. A level is accepted into `data/levels.json` **only** if:
1. Its layout hash is 100% unique across all 500 levels.
2. The automated solver clears the level (all non-stone bubbles cleared or Boss HP reduced to 0) within the target shot ceiling.
3. Its final `shots` budget is tightly calibrated to `solver_shots + world_margin` (hard, fair, zero impossible deadlocks).

---

## 5. Visuals, Shaders & Animation Polish

- **Cohesive Neon-Gloss Palette**: Deep obsidian-indigo playfield (`#07091A`–`#120B2E`) paired with 7 high-luminance glossy neon orbs (Electric Cyan, Plasma Magenta, Solar Amber, Hyper Lime, Cobalt Violet, Crimson Nova, Prism Pearl) — each featuring subtle inner geometric emblems for instant readability.
- **Custom Shaders**:
  - `neon_bg.gdshader`: Smooth GPU-driven dual-tone aurora nebula shift customized per world theme.
  - `bubble_gloss.gdshader`: Animated Fresnel rim sheen and specular pulse for bombs, rainbows, and active shots.
- **Juice & Motion**:
  - Shooter cannon spring recoil + muzzle glow flash on every shot.
  - Staggered BFS pop ripples (25 ms per ring) with radial particle bursts and expanding shockwave rings.
  - Physics-driven detached bubbles with gravity, spin, wall bounce, and floating score popups (`+150`, `+500 DROP!`).
  - Dynamic camera screen shake proportional to cluster size, bomb blasts, and boss hits.
  - Animated 3-star victory cascade, confetti particles, and smooth fade/slide menu transitions.

---

## 6. Sound Design & Dynamic World Music (Top Priority)

All audio is procedurally synthesized via studio-grade DSP (`numpy` + `scipy` + `ffmpeg`) — 100% original and royalty-free:

- **Layered SFX Suite (17 assets)**:
  - `sfx_shoot.wav`: Sub-bass transient + pneumatic whoosh + neon chirp.
  - `sfx_bounce.wav`: Crystalline wall-ricochet harmonic ping.
  - `sfx_pop_1.wav` – `sfx_pop_8.wav`: 8-step musical pentatonic/lydian pop ladder so consecutive combos climb in pitch and sparkle.
  - `sfx_drop.wav`, `sfx_ice_crack.wav`, `sfx_lock_break.wav`, `sfx_stone_clink.wav`, `sfx_bomb.wav`, `sfx_lightning.wav`, `sfx_rainbow.wav`, `sfx_swap.wav`, `sfx_boss_hit.wav`, `sfx_ceiling_drop.wav`, `sfx_win.wav`, `sfx_lose.wav`, `sfx_ui_tap.wav`, `sfx_ui_back.wav`.
- **Dynamic World Music (5 seamless OGG loops)**:
  - `bgm_menu.ogg`: Lush ambient synthwave pad & arpeggio.
  - `bgm_world_cyber.ogg` (112 BPM), `bgm_world_volt.ogg` (122 BPM), `bgm_world_quantum.ogg` (128 BPM), `bgm_world_apex.ogg` (136 BPM).
  - Real-time Godot audio bus modulation: low-pass filter sweep during Pause, dynamic pitch/gain lift during Boss Battles and Final-5-Shots tension, plus granular Master/Music/SFX volume sliders and instant mute toggles.

---

## 7. UI/UX, Progression & Haptics

- **Thumb-Friendly Portrait Ergonomics**: 1080×1920 reference viewport (`canvas_items` stretch with `expand` aspect for 20:9 / 21:9 Android 16 displays). Drag anywhere in the playfield to aim; drag below the shooter baseline to cancel a shot safely.
- **Complete Screen Flow**: Animated Splash → Main Menu → 10-World Interactive Map (500 nodes with star badges & boss crowns) → Gameplay HUD → Pause / Settings / Win / Lose overlays.
- **Meta-Progression**: 5 regenerating lives (20-minute recharge), 1–3 Star rating per level, 4 strategic power-ups (**Bomb**, **Lightning Row**, **Color Swap**, **Aim Guide**) earned via star milestones and boss clears, and atomic JSON local saves.
- **Haptics**: Calibrated Android vibration pulses (`12 ms` tap, `18 ms` pop, `35 ms` combo, `65 ms` bomb/boss) with instant toggle in Settings.

---

## 8. Performance & Battery Optimization (Android 16)

- **High Refresh Rate Support**: VSync enabled with adaptive frame pacing supporting 60 Hz, 90 Hz, and 120 Hz Android displays (`Engine.max_fps` configurable in Settings: 60 fps Battery Saver vs. Unlimited/120 fps Ultra Smooth).
- **Zero-GC Gameplay Loop**: Pooled SFX players, lightweight `CanvasItem` draw batching for the aim trajectory, and pre-cached textures prevent frame hitches.
- **Thermal Efficiency**: Single-pass background shader with no heavy post-processing bloom passes; particles auto-sleep when idle.

---

## 9. Testing & Verification Strategy

1. **Level Uniqueness & Solvability Suite**: Automated Python physics solver validates 500/500 unique layouts and 500/500 verifiable clears.
2. **Static Project & GDScript Integrity Check**: Automated test script validates `project.godot`, all `.tscn` scene references, all `res://` texture/shader/audio asset paths, and `levels.json` schema integrity.
3. **CI Pre-Build Gate**: GitHub Actions executes `tools/run_tests.py` before invoking Godot Android export so broken builds fail fast.

---

## 10. Build, Signing & Deployment Pipeline

- **Automated GitHub Actions Workflow (`.github/workflows/build-apk.yml`)**:
  - Downloads Godot 4.3-stable Linux headless binary + official Android export templates.
  - Configures JDK 17 + Android SDK Platform 35 & Build Tools 35.0.0 (fully compatible with Android 16).
  - Signs the release APK using either user-supplied GitHub Secrets (`ANDROID_KEYSTORE_BASE64`, etc.) or an automatically generated release keystore so the resulting `NeonBubbleSurge-release.apk` installs directly on Android 16 phones.
  - Uploads the signed APK as a downloadable workflow artifact.
