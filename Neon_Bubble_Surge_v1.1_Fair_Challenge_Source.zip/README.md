# Neon Bubble Surge — v1.1 Fair-Challenge Update

Godot 4.3 Android portrait bubble shooter, updated **in place** from the `neon-bubble-surge-source-v3.zip` found in the user's uploaded `Bubble-shooter-main.zip`.

## What changed

- **500 distinct existing layouts retained.** Each now has a recorded starting-ammo sequence, landing-cell targets, and an angle-based witness plan from an independent bubble-physics simulator (see `data/levels.json` and `tools/playability_report.json`). A witness is **not** a guarantee that any arbitrary series of shots can win.
- **Broken original solver identified.** It could choose any existing color on every turn, while the real shooter offers just two. This meant its old "500/500 solver verified" report did not validate the playable ammo sequence. The legacy generator is blocked from overwriting the improved levels by default.
- **Shot budgets rebalanced** against the constructive witness instead of the optimistic old solver. Level 11 is now 25 shots (previously 14), with an independently replayed 21-shot reference route.
- **Level 480 boss** tuned from 24 HP/14 shots/60 seconds to 18 HP/52 shots/250 seconds; replay reference takes 48 shots.
- **Deterministic ammunition path** follows a tested reference solution as long as the player's landing cells match that solution. Any alternative shot or bubble swap **immediately switches to adaptive ammo**, so personal strategies remain possible.
- **Adaptive recovery.** Future colors are generated after impact, from still-matchable normal bubbles (not stale colors on the prior board). After two nonproductive shots, or if there are no matchable normal bubbles, a **BREAKER** bomb is loaded. It consumes one normal shot from the budget but does not require a purchased powerup. Once per level, a player making progress but running out of shots may receive 3 clutch shots.
- **Touch control:** tap the loaded bubble or the next bubble to exchange colors; drag downward to the cancel zone, swipe down sufficiently, or touch with a second finger while aiming to cancel. Cancellation cannot consume a shot. Prevent Android simulated-mouse double taps.
- **Grid geometry:** descending ceiling now moves the visual Y positions without changing row parity and width, preventing layout distortions.
- **Timed and ceiling-pressure stages:** timers are calibrated to reference shot lengths and descent does not invalidate the shortest recorded reference route. Players taking extra shots can still encounter descending-ceiling pressure.

## Important validation scope

The test system generated and replayed 500 constructive action sequences using a **separate Python approximation** of Godot's collision, snap-to-grid, special bubble and boss rules. It verified unique layouts, shot budgets, reference ammo, and replay clear conditions. **This is not a live Godot/Android playtest**, nor an exhaustive proof for every possible touch input, variation in frame timing, alternative shot order, or misuse of shots. A player can still lose by using shots badly or reaching the danger line.

For actual app-level verification, open the project in **Godot 4.3** and run the scenes on an Android phone. Local static integrity checks pass; Godot and Android SDK were not installed in this environment, so an APK was not built here.

## Controls

1. **Change ball:** short tap on the cannon bubble or the smaller next bubble.
2. **Aim:** press and drag in the playfield, or pull back a short distance from the shooter bubble.
3. **Fire:** release on a valid upward trajectory.
4. **Cancel:** swipe down from the playfield, pull the loaded bubble beyond the pullback cancellation distance, or touch the screen with a second finger while still aiming. A cancelled shot doesn't decrement the shot counter.

## Building

- Integrity tests: `python3 tools/run_tests.py`
- Optional physics audit (requires NumPy): `python3 tools/audit_playability.py --levels 11`
- Open `project.godot` in Godot **4.3** (Mobile/GL compatibility).
- GitHub Actions: add this source directory to a repo, then run **Build Signed Android APK (Godot 4.3)** under **Actions**. The workflow includes source integrity tests, Godot asset import, Android export, and signature verification.

**Updates on an installed phone:** Use the **same Android signing keystore** for every version, or Android may reject the APK as an update. The example workflow creates a temporary key when a stable keystore is not supplied; reinstalling under a different signing key may require uninstalling first and can erase local game progress. Back up saves first.

The original source generators, visual assets, music, and Android build workflow are retained. See `CHANGELOG_BN.md` for a Bengali summary and `tools/level_budget_changes.csv` for per-level figures.
