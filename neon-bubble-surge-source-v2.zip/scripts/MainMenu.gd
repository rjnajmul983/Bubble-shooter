extends Control

var _floaters: Array[Sprite2D] = []
var _floater_vels: Array[Vector2] = []
var _settings_overlay: Control
var _lbl_stats: Label


func _ready() -> void:
	AudioManager.play_bgm("bgm_menu.ogg", 0.6)
	_build_background()
	_build_ui()


func _build_background() -> void:
	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	var mat := ShaderMaterial.new()
	mat.shader = load("res://assets/shaders/neon_bg.gdshader")
	mat.set_shader_parameter("color_top", Color("#07091C"))
	mat.set_shader_parameter("color_bot", Color("#1C1042"))
	mat.set_shader_parameter("accent_color", Color("#00F5FF"))
	bg.material = mat
	add_child(bg)

	# Ambient floating glossy bubbles
	for i in range(14):
		var sp := Sprite2D.new()
		sp.texture = load("res://assets/textures/bubble_%d.png" % (i % 7))
		var sc := randf_range(0.32, 0.68)
		sp.scale = Vector2(sc, sc)
		sp.position = Vector2(randf_range(60, 1020), randf_range(80, 1840))
		sp.modulate.a = randf_range(0.22, 0.45)
		add_child(sp)
		_floaters.append(sp)
		_floater_vels.append(Vector2(randf_range(-24, 24), randf_range(-55, -22)))


func _process(delta: float) -> void:
	for i in range(_floaters.size()):
		var sp := _floaters[i]
		sp.position += _floater_vels[i] * delta
		if sp.position.y < -90:
			sp.position.y = 2010
			sp.position.x = randf_range(60, 1020)
		if sp.position.x < -60:
			sp.position.x = 1140
		elif sp.position.x > 1140:
			sp.position.x = -60


func _build_ui() -> void:
	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 72
	vb.offset_right = -72
	vb.offset_top = 140
	vb.offset_bottom = -140
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 34)
	add_child(vb)

	var icon := TextureRect.new()
	icon.texture = load("res://icon.png")
	icon.custom_minimum_size = Vector2(210, 210)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(icon)

	var title := Label.new()
	title.text = "NEON BUBBLE\nSURGE"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 82)
	title.add_theme_color_override("font_color", Color("#00F5FF"))
	vb.add_child(title)

	var badge := Label.new()
	badge.text = "HARDCORE 500-LEVEL EDITION"
	badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	badge.add_theme_font_size_override("font_size", 28)
	badge.add_theme_color_override("font_color", Color("#FF2A85"))
	vb.add_child(badge)

	_lbl_stats = Label.new()
	_lbl_stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_lbl_stats.add_theme_font_size_override("font_size", 30)
	_lbl_stats.add_theme_color_override("font_color", Color("#E2E8F0"))
	vb.add_child(_lbl_stats)
	_refresh_stats()

	var frontier: int = int(SaveManager.data.get("unlocked_level", 1))
	var btn_play := _make_btn("PLAY LEVEL %d" % frontier, Color("#059669"), 112, 40)
	btn_play.pressed.connect(func():
		AudioManager.play_sfx("sfx_ui_tap")
		HapticsManager.tap()
		LevelData.selected_level_id = frontier
		get_tree().change_scene_to_file("res://scenes/Game.tscn")
	)
	vb.add_child(btn_play)

	var btn_map := _make_btn("WORLD MAP (500 LEVELS)", Color("#2563EB"), 98, 34)
	btn_map.pressed.connect(func():
		AudioManager.play_sfx("sfx_ui_tap")
		HapticsManager.tap()
		get_tree().change_scene_to_file("res://scenes/WorldMap.tscn")
	)
	vb.add_child(btn_map)

	var btn_settings := _make_btn("SETTINGS & AUDIO", Color("#475569"), 90, 32)
	btn_settings.pressed.connect(func():
		AudioManager.play_sfx("sfx_ui_tap")
		HapticsManager.tap()
		_open_settings()
	)
	vb.add_child(btn_settings)


func _refresh_stats() -> void:
	var lives := SaveManager.get_lives()
	var stars := SaveManager.get_total_stars()
	_lbl_stats.text = "♥ %d/5 LIVES   •   ★ %d/1500 STARS   •   SCORE %d" % [
		lives, stars, int(SaveManager.data.get("total_score", 0))
	]


func _make_btn(txt: String, col: Color, h: float, font_sz: int) -> Button:
	var b := Button.new()
	b.text = txt
	b.custom_minimum_size = Vector2(0, h)
	b.add_theme_font_size_override("font_size", font_sz)
	b.add_theme_color_override("font_color", Color.WHITE)
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	sb.corner_radius_top_left = 24
	sb.corner_radius_top_right = 24
	sb.corner_radius_bottom_left = 24
	sb.corner_radius_bottom_right = 24
	sb.border_width_left = 2
	sb.border_width_top = 2
	sb.border_width_right = 2
	sb.border_width_bottom = 5
	sb.border_color = col.lightened(0.45)
	b.add_theme_stylebox_override("normal", sb)
	var sbh := sb.duplicate()
	sbh.bg_color = col.lightened(0.14)
	b.add_theme_stylebox_override("hover", sbh)
	b.add_theme_stylebox_override("pressed", sbh)
	return b


func _open_settings() -> void:
	if _settings_overlay != null:
		_settings_overlay.queue_free()
	_settings_overlay = Control.new()
	_settings_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_settings_overlay)

	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.02, 0.03, 0.08, 0.84)
	_settings_overlay.add_child(dim)

	var card := PanelContainer.new()
	card.position = Vector2(80, 320)
	card.size = Vector2(920, 1180)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.06, 0.08, 0.18, 0.97)
	sb.corner_radius_top_left = 30
	sb.corner_radius_top_right = 30
	sb.corner_radius_bottom_left = 30
	sb.corner_radius_bottom_right = 30
	sb.border_width_left = 3
	sb.border_width_top = 3
	sb.border_width_right = 3
	sb.border_width_bottom = 3
	sb.border_color = Color("#00F5FF")
	sb.content_margin_left = 48
	sb.content_margin_right = 48
	sb.content_margin_top = 48
	sb.content_margin_bottom = 48
	card.add_theme_stylebox_override("panel", sb)
	_settings_overlay.add_child(card)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 26)
	card.add_child(vb)

	var hdr := Label.new()
	hdr.text = "SETTINGS"
	hdr.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hdr.add_theme_font_size_override("font_size", 48)
	hdr.add_theme_color_override("font_color", Color("#00F5FF"))
	vb.add_child(hdr)

	_add_slider_row(vb, "Music Volume", "music_vol")
	_add_slider_row(vb, "SFX Volume", "sfx_vol")
	_add_toggle_row(vb, "Mute Music", "music_muted")
	_add_toggle_row(vb, "Mute SFX", "sfx_muted")
	_add_toggle_row(vb, "Haptic Vibration", "haptics")
	_add_toggle_row(vb, "High Refresh Rate (60/120Hz)", "high_fps")

	var btn_close := _make_btn("SAVE & CLOSE", Color("#059669"), 92, 34)
	btn_close.pressed.connect(func():
		AudioManager.play_sfx("sfx_ui_back")
		_settings_overlay.queue_free()
		_settings_overlay = null
	)
	vb.add_child(btn_close)


func _add_slider_row(parent: VBoxContainer, label_txt: String, key: String) -> void:
	var lbl := Label.new()
	lbl.text = label_txt
	lbl.add_theme_font_size_override("font_size", 30)
	parent.add_child(lbl)

	var sl := HSlider.new()
	sl.min_value = 0.0
	sl.max_value = 1.0
	sl.step = 0.05
	sl.value = float(SaveManager.get_setting(key, 0.8))
	sl.custom_minimum_size = Vector2(0, 44)
	sl.value_changed.connect(func(v: float):
		SaveManager.set_setting(key, v)
		AudioManager.apply_settings()
	)
	parent.add_child(sl)


func _add_toggle_row(parent: VBoxContainer, label_txt: String, key: String) -> void:
	var chk := CheckButton.new()
	chk.text = label_txt
	chk.button_pressed = bool(SaveManager.get_setting(key, false))
	chk.add_theme_font_size_override("font_size", 30)
	chk.toggled.connect(func(pressed: bool):
		SaveManager.set_setting(key, pressed)
		AudioManager.apply_settings()
		AudioManager.play_sfx("sfx_ui_tap")
	)
	parent.add_child(chk)
