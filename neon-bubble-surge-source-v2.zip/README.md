# Neon Bubble Surge

A hardcore, neon-gloss 2D Android bubble shooter built with **Godot 4.3**, featuring **500 unique solver-validated levels**, **50 Boss battles**, **layered procedural SFX & dynamic world music**, and a turnkey **GitHub Actions signed APK pipeline**.

## Highlights
- **500 Unique, Demanding Levels across 10 Neon Worlds**: Escalating from 5 to 7 colors with stone blockers, 2-hit ice bubbles, locked chains, embedded bombs, rainbow wildcards, descending ceilings, countdown timers, and a Boss encounter every 10th level.
- **100% Solver-Verified**: Every layout is verified solvable by `tools/generate_levels.py`, with tight shot budgets derived from solver par clears.
- **Tactile Audio & Visuals**: 24 layered procedural WAV SFX (including an 8-step pitch-escalating combo ladder), 5 seamlessly looping stereo synthwave OGG tracks, custom neon aurora shaders, screen shake, recoil, and Android haptics.
- **Android 16 Ready**: Portrait 1080×1920 responsive scaling, 60/120 Hz toggle in Settings, minimal battery drain, `arm64-v8a` + `armeabi-v7a` release export.

---

## How to Build the Signed APK via GitHub Actions (No PC / Android Studio Needed)

1. Create a new repository on GitHub (public or private).
2. Extract `neon-bubble-surge-source.zip` and upload all files (preserving the `.github/workflows/build-apk.yml` folder path) to the repository root.
3. Open the **Actions** tab on GitHub and click **Build Signed Android APK (Godot 4.3)** → **Run workflow** (or push to `main`).
4. Wait ~2–3 minutes for the build to finish.
5. Download the **NeonBubbleSurge-release-apk** artifact, unzip it, and install `NeonBubbleSurge-release.apk` directly on your Android 16 phone (enable *Install unknown apps* if prompted).

### Optional: Use Your Own Release Keystore
By default, the workflow automatically generates a release keystore and signs the APK so it installs immediately. To use your own persistent keystore across updates, add these repository secrets under **Settings → Secrets and variables → Actions**:
- `ANDROID_KEYSTORE_BASE64` (base64-encoded `.keystore` file)
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

---

## Local Build & Testing (Optional)
- Run integrity tests: `python3 tools/run_tests.py`
- Regenerate & re-validate 500 levels: `python3 tools/generate_levels.py`
- Open `project.godot` in **Godot 4.3** to playtest or export directly to Android.
