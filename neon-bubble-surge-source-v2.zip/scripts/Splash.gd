extends Control

var _timer := 0.0
var _done := false


func _ready() -> void:
	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	var mat := ShaderMaterial.new()
	mat.shader = load("res://assets/shaders/neon_bg.gdshader")
	bg.material = mat
	add_child(bg)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_CENTER)
	vb.offset_left = -420
	vb.offset_right = 420
	vb.offset_top = -280
	vb.offset_bottom = 280
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 24)
	add_child(vb)

	var icon := TextureRect.new()
	icon.texture = load("res://icon.png")
	icon.custom_minimum_size = Vector2(240, 240)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(icon)

	var title := Label.new()
	title.text = "NEON BUBBLE SURGE"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 64)
	title.add_theme_color_override("font_color", Color("#00F5FF"))
	vb.add_child(title)

	var sub := Label.new()
	sub.text = "500 TACTICAL LEVELS • 10 NEON WORLDS"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 28)
	sub.add_theme_color_override("font_color", Color("#FF2A85"))
	vb.add_child(sub)

	vb.modulate.a = 0.0
	vb.scale = Vector2(0.85, 0.85)
	vb.pivot_offset = Vector2(420, 280)
	var tw := create_tween().set_parallel(true).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(vb, "modulate:a", 1.0, 0.65)
	tw.tween_property(vb, "scale", Vector2.ONE, 0.65)

	AudioManager.play_bgm("bgm_menu.ogg", 0.6)


func _process(delta: float) -> void:
	if _done:
		return
	_timer += delta
	if _timer >= 1.65:
		_go_menu()


func _unhandled_input(event: InputEvent) -> void:
	if _done:
		return
	if (event is InputEventScreenTouch and event.pressed) or (event is InputEventMouseButton and event.pressed):
		_go_menu()


func _go_menu() -> void:
	_done = true
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
